<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\File;
use Pterodactyl\Http\Controllers\Controller;

/**
 * Admin → Appearance: the panel-wide look, announcement banner and quick links.
 * Values live in storage/app/vizion/settings.json and are embedded into every page by wrapper.blade.php.
 */
class VizionController extends Controller
{
    private const HEX = ['required', 'string', 'regex:/^#[0-9a-fA-F]{6}$/'];
    private const URL = '#^(https?://|mailto:|/(?!/))[^\s"\'<>\\\\]*$#i';

    /** First existing file among the bundled/placed default pictures, as a public URL (or ''). */
    private static function defaultPicture(string $base): string
    {
        foreach (['webp', 'jpg', 'jpeg', 'png'] as $ext) {
            if (is_file(public_path("vizion/{$base}.{$ext}"))) {
                return "/vizion/{$base}.{$ext}";
            }
        }

        return '';
    }

    public static function defaults(): array
    {
        $card = self::defaultPicture('card-default');
        $login = self::defaultPicture('login-default');

        return [
            'appearance' => [
                'mode' => 'dark',
                'accent' => '#4F8CFF',
                'radius' => 10,
                'density' => 'comfortable',
                'font' => 'default',
                'motion' => 'full',
                'bg' => 'dots',
                'bgColor' => '#0A0E14',
                'bgGradient' => ['from' => '#0A0E14', 'to' => '#14213A', 'angle' => 160],
                'bgImage' => '',
                'bgBlur' => 0,
                'bgDim' => 55,
            ],
            'cards' => ['enabled' => $card !== '', 'image' => $card, 'dim' => 70, 'blur' => 0],
            'branding' => ['logo' => '', 'showName' => true],
            'login' => ['enabled' => $login !== '', 'image' => $login, 'dim' => 25, 'blur' => 0],
            'announcement' => [
                'enabled' => false,
                'type' => 'info',
                'title' => '',
                'message' => '',
                'linkLabel' => '',
                'linkUrl' => '',
                'dismissible' => true,
                'rev' => 0,
            ],
            'links' => ['enabled' => false, 'items' => []],
        ];
    }

    public static function stored(): array
    {
        $file = storage_path('app/vizion/settings.json');
        $saved = is_file($file) ? json_decode((string) @file_get_contents($file), true) : null;

        return is_array($saved) ? array_replace_recursive(self::defaults(), array_intersect_key($saved, self::defaults())) : self::defaults();
    }

    public function index(): View
    {
        return view('admin.vizion.index', ['settings' => self::stored()]);
    }

    public function save(Request $request): JsonResponse
    {
        $data = $request->validate([
            'appearance' => 'required|array',
            'appearance.mode' => 'required|in:system,light,dark,oled',
            'appearance.accent' => self::HEX,
            'appearance.radius' => 'required|integer|between:2,20',
            'appearance.density' => 'required|in:comfortable,compact',
            'appearance.font' => 'required|in:default,system,plex',
            'appearance.motion' => 'required|in:full,reduced',
            'appearance.bg' => 'required|in:dots,glow,plain,color,gradient,image',
            'appearance.bgColor' => self::HEX,
            'appearance.bgGradient.from' => self::HEX,
            'appearance.bgGradient.to' => self::HEX,
            'appearance.bgGradient.angle' => 'required|integer|between:0,360',
            'appearance.bgImage' => ['present', 'nullable', 'string', 'max:300', 'regex:' . self::URL],
            'appearance.bgBlur' => 'required|integer|between:0,24',
            'appearance.bgDim' => 'required|integer|between:0,90',

            'cards' => 'required|array',
            'cards.enabled' => 'required|boolean',
            'cards.image' => ['present', 'nullable', 'string', 'max:300', 'regex:' . self::URL],
            'cards.dim' => 'required|integer|between:40,95',
            'cards.blur' => 'required|integer|between:0,12',

            'branding' => 'required|array',
            'branding.logo' => ['present', 'nullable', 'string', 'max:300', 'regex:' . self::URL],
            'branding.showName' => 'required|boolean',

            'login' => 'required|array',
            'login.enabled' => 'required|boolean',
            'login.image' => ['present', 'nullable', 'string', 'max:300', 'regex:' . self::URL],
            'login.dim' => 'required|integer|between:0,90',
            'login.blur' => 'required|integer|between:0,16',

            'announcement' => 'required|array',
            'announcement.enabled' => 'required|boolean',
            'announcement.type' => 'required|in:info,success,warning,danger',
            'announcement.title' => 'present|nullable|string|max:80',
            'announcement.message' => 'present|nullable|string|max:400',
            'announcement.linkLabel' => 'present|nullable|string|max:40',
            'announcement.linkUrl' => ['present', 'nullable', 'string', 'max:300', 'regex:' . self::URL],
            'announcement.dismissible' => 'required|boolean',

            'links' => 'required|array',
            'links.enabled' => 'required|boolean',
            'links.items' => 'present|array|max:8',
            'links.items.*.label' => 'required|string|max:40',
            'links.items.*.url' => ['required', 'string', 'max:300', 'regex:' . self::URL],
            'links.items.*.icon' => 'required|in:chat,support,docs,status,web,store',
            'links.items.*.enabled' => 'required|boolean',
        ]);

        $data['appearance']['bgImage'] = $data['appearance']['bgImage'] ?? '';
        $data['cards']['image'] = $data['cards']['image'] ?? '';
        $data['branding']['logo'] = $data['branding']['logo'] ?? '';
        $data['login']['image'] = $data['login']['image'] ?? '';
        foreach (['title', 'message', 'linkLabel', 'linkUrl'] as $key) {
            $data['announcement'][$key] = trim((string) ($data['announcement'][$key] ?? ''));
        }

        // Bump the revision when the banner text changes so people who dismissed the old one see the new one.
        $previous = self::stored()['announcement'];
        $changed = ($previous['title'] ?? '') !== $data['announcement']['title']
            || ($previous['message'] ?? '') !== $data['announcement']['message']
            || ($previous['linkUrl'] ?? '') !== $data['announcement']['linkUrl'];
        $data['announcement']['rev'] = (int) ($previous['rev'] ?? 0) + ($changed ? 1 : 0);
        $data['links']['items'] = array_values($data['links']['items']);

        $dir = storage_path('app/vizion');
        File::ensureDirectoryExists($dir);
        File::put($dir . '/settings.json', json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), true);

        return new JsonResponse(['ok' => true]);
    }

    public function background(Request $request): JsonResponse
    {
        $target = (string) $request->input('target');
        $request->validate([
            'target' => 'required|in:page,cards,logo,login',
            'image' => 'required|file|mimes:jpg,jpeg,png,webp|max:' . ($target === 'logo' ? 2048 : 6144),
        ]);

        $prefix = ['page' => 'background', 'cards' => 'card', 'logo' => 'logo', 'login' => 'login'][$target];
        $dir = public_path('vizion');
        File::ensureDirectoryExists($dir);
        self::purge($prefix);

        $file = $request->file('image');
        $ext = strtolower((string) $file->guessExtension());
        $ext = in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true) ? $ext : 'jpg';
        $name = $prefix . '-' . bin2hex(random_bytes(6)) . '.' . $ext;
        $file->move($dir, $name);

        return new JsonResponse(['url' => '/vizion/' . $name]);
    }

    public function reset(): JsonResponse
    {
        File::delete(storage_path('app/vizion/settings.json'));
        self::purge();

        return new JsonResponse(self::defaults());
    }

    /** Deletes uploaded pictures only (name-<12 hex>.ext). The bundled *-default files are never touched. */
    private static function purge(?string $prefix = null): void
    {
        foreach (File::glob(public_path('vizion/*')) ?: [] as $path) {
            if (preg_match('/^' . ($prefix ?? '(background|card|logo|login)') . '-[0-9a-f]{12}\.(jpe?g|png|webp)$/', basename($path))) {
                File::delete($path);
            }
        }
    }
}
