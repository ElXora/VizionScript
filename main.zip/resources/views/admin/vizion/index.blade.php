@extends('layouts.admin')

@section('title')
    Appearance
@endsection

@section('content-header')
    <h1>Appearance<small>The look of the whole panel, announcement banner and quick links.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Appearance</li>
    </ol>
@endsection

@section('content')
    <div class="vz-ap">
        <div>
            <div class="box box-primary">
                <div class="box-body">
                    <div class="vz-ap-tabs" role="tablist">
                        <button type="button" role="tab" data-tab="look" aria-selected="true">Look</button>
                        <button type="button" role="tab" data-tab="cards" aria-selected="false">Server cards</button>
                        <button type="button" role="tab" data-tab="ann" aria-selected="false">Announcement</button>
                        <button type="button" role="tab" data-tab="links" aria-selected="false">Links</button>
                    </div>

                    {{-- LOOK --}}
                    <div class="vz-ap-pane on" data-pane="look">
                        <div class="vz-ap-sec">
                            <div class="vz-ap-lab">Mode</div>
                            <div class="vz-ap-seg" data-seg="appearance.mode">
                                <button type="button" data-v="system">System</button>
                                <button type="button" data-v="light">Light</button>
                                <button type="button" data-v="dark">Dark</button>
                                <button type="button" data-v="oled">OLED</button>
                            </div>
                            <p class="vz-ap-note">"System" follows each visitor's device setting. Everyone sees the mode you choose here.</p>
                        </div>
                        <div class="vz-ap-sec">
                            <div class="vz-ap-lab">Accent colour <b id="accentLabel"></b></div>
                            <div class="vz-ap-sw" id="swatches"></div>
                            <div class="vz-ap-row">
                                <input type="color" data-k="appearance.accent" aria-label="Accent colour">
                                <input type="text" class="form-control" data-k="appearance.accent" maxlength="7" spellcheck="false" aria-label="Accent hex value">
                            </div>
                        </div>
                        <div class="vz-ap-sec">
                            <div class="vz-ap-lab">Background</div>
                            <div class="vz-ap-seg" data-seg="appearance.bg">
                                <button type="button" data-v="dots">Dots</button>
                                <button type="button" data-v="glow">Glow</button>
                                <button type="button" data-v="plain">Plain</button>
                                <button type="button" data-v="color">Colour</button>
                                <button type="button" data-v="gradient">Gradient</button>
                                <button type="button" data-v="image">Image</button>
                            </div>
                            <div data-show="appearance.bg=color" class="vz-ap-row">
                                <input type="color" data-k="appearance.bgColor" aria-label="Background colour"><span class="vz-ap-note" style="margin:0">Solid colour behind everything</span>
                            </div>
                            <div data-show="appearance.bg=gradient" class="vz-ap-row">
                                <input type="color" data-k="appearance.bgGradient.from" aria-label="Gradient start">
                                <input type="color" data-k="appearance.bgGradient.to" aria-label="Gradient end">
                                <input type="range" min="0" max="360" data-k="appearance.bgGradient.angle" data-t="num" aria-label="Gradient angle">
                            </div>
                            <div data-show="appearance.bg=image">
                                <div class="vz-ap-row">
                                    <label class="btn btn-default" style="margin:0">Upload image<input type="file" accept="image/*" hidden data-upload="page"></label>
                                    <button type="button" class="btn btn-default" data-clear="appearance.bgImage">Remove</button>
                                </div>
                                <div class="vz-ap-lab" style="margin-top:14px">Blur <b data-out="appearance.bgBlur"></b></div>
                                <input type="range" min="0" max="24" data-k="appearance.bgBlur" data-t="num" style="width:100%" aria-label="Background blur">
                                <div class="vz-ap-lab" style="margin-top:10px">Darken <b data-out="appearance.bgDim"></b></div>
                                <input type="range" min="0" max="90" data-k="appearance.bgDim" data-t="num" style="width:100%" aria-label="Background darkening">
                                <p class="vz-ap-note">JPG, PNG or WebP up to 6 MB. It also shows behind the login page.</p>
                            </div>
                        </div>
                        <div class="vz-ap-sec">
                            <div class="vz-ap-lab">Corner radius <b data-out="appearance.radius"></b></div>
                            <input type="range" min="2" max="20" data-k="appearance.radius" data-t="num" style="width:100%" aria-label="Corner radius">
                        </div>
                        <div class="vz-ap-sec">
                            <div class="vz-ap-lab">Density</div>
                            <div class="vz-ap-seg" data-seg="appearance.density"><button type="button" data-v="comfortable">Comfortable</button><button type="button" data-v="compact">Compact</button></div>
                            <div class="vz-ap-lab" style="margin-top:16px">Typeface</div>
                            <div class="vz-ap-seg" data-seg="appearance.font"><button type="button" data-v="default">Default</button><button type="button" data-v="system">System</button><button type="button" data-v="plex">Plex</button></div>
                            <div class="vz-ap-lab" style="margin-top:16px">Motion</div>
                            <div class="vz-ap-seg" data-seg="appearance.motion"><button type="button" data-v="full">Full</button><button type="button" data-v="reduced">Reduced</button></div>
                        </div>
                    </div>

                    {{-- SERVER CARDS --}}
                    <div class="vz-ap-pane" data-pane="cards">
                        <div class="vz-ap-sec">
                            <label class="vz-ap-check"><input type="checkbox" data-k="cards.enabled" data-t="bool"> Show a picture on the server cards</label>
                            <p class="vz-ap-note">The picture sits behind every server card on the dashboard. A dark layer keeps the text readable.</p>
                        </div>
                        <div class="vz-ap-sec">
                            <div class="vz-ap-row" style="margin-top:0">
                                <label class="btn btn-default" style="margin:0">Upload picture<input type="file" accept="image/*" hidden data-upload="cards"></label>
                                <button type="button" class="btn btn-default" data-clear="cards.image">Remove</button>
                            </div>
                            <div class="vz-ap-lab" style="margin-top:14px">Darken <b data-out="cards.dim"></b></div>
                            <input type="range" min="40" max="95" data-k="cards.dim" data-t="num" style="width:100%" aria-label="Card darkening">
                            <div class="vz-ap-lab" style="margin-top:10px">Blur <b data-out="cards.blur"></b></div>
                            <input type="range" min="0" max="12" data-k="cards.blur" data-t="num" style="width:100%" aria-label="Card blur">
                            <p class="vz-ap-note">Only upload pictures you have the right to use.</p>
                        </div>
                    </div>

                    {{-- ANNOUNCEMENT --}}
                    <div class="vz-ap-pane" data-pane="ann">
                        <div class="vz-ap-sec">
                            <label class="vz-ap-check"><input type="checkbox" data-k="announcement.enabled" data-t="bool"> Show the announcement banner</label>
                            <p class="vz-ap-note">Appears under the top bar on every page of the panel. Changing the text shows it again to people who dismissed the old one.</p>
                        </div>
                        <div class="vz-ap-sec">
                            <div class="vz-ap-lab">Style</div>
                            <div class="vz-ap-seg" data-seg="announcement.type"><button type="button" data-v="info">Info</button><button type="button" data-v="success">Success</button><button type="button" data-v="warning">Warning</button><button type="button" data-v="danger">Danger</button></div>
                            <div class="vz-ap-lab" style="margin-top:16px">Title</div>
                            <input type="text" class="form-control" data-k="announcement.title" maxlength="80" placeholder="Scheduled maintenance">
                            <div class="vz-ap-lab" style="margin-top:14px">Message</div>
                            <textarea class="form-control" rows="3" data-k="announcement.message" maxlength="400" placeholder="What do your users need to know?"></textarea>
                            <div class="vz-ap-row">
                                <input type="text" class="form-control" data-k="announcement.linkLabel" maxlength="40" placeholder="Button text (optional)">
                                <input type="text" class="form-control" data-k="announcement.linkUrl" maxlength="300" placeholder="https://… (optional)">
                            </div>
                            <div class="vz-ap-row"><label class="vz-ap-check"><input type="checkbox" data-k="announcement.dismissible" data-t="bool"> Visitors can dismiss it</label></div>
                        </div>
                    </div>

                    {{-- LINKS --}}
                    <div class="vz-ap-pane" data-pane="links">
                        <div class="vz-ap-sec">
                            <label class="vz-ap-check"><input type="checkbox" data-k="links.enabled" data-t="bool"> Show quick links</label>
                            <p class="vz-ap-note">Shown in the top bar and on the login page, for example Discord or your support site. Each link can be switched on or off.</p>
                        </div>
                        <div class="vz-ap-sec">
                            <div class="vz-ap-links" id="linkRows"></div>
                            <div class="vz-ap-row">
                                <button type="button" class="btn btn-default" id="addLink">Add link</button>
                                <button type="button" class="btn btn-default" data-preset="Discord|chat">+ Discord</button>
                                <button type="button" class="btn btn-default" data-preset="Support center|support">+ Support center</button>
                            </div>
                            <p class="vz-ap-note">Up to 8 links. Use full addresses starting with https://</p>
                        </div>
                    </div>

                    <div class="vz-ap-foot">
                        <button type="button" class="btn btn-primary" id="save">Save for everyone</button>
                        <button type="button" class="btn btn-default" id="reset">Reset to defaults</button>
                        <span class="vz-ap-status" id="status" role="status"></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="vz-ap-side">
            <div class="vz-ap-lab" style="margin-bottom:8px">Live preview</div>
            <div class="vzp" id="preview" data-m="dark">
                <div class="vzp-stage" id="pvStage"></div><div class="vzp-dim" id="pvDim"></div>
                <div class="vzp-side"><b></b><i class="on"></i><i></i><i></i></div>
                <div class="vzp-main">
                    <div class="vzp-top"><span>Servers</span><div id="pvLinks"></div></div>
                    <div class="vzp-ann" id="pvAnn" data-t="info"><b id="pvAnnT"></b><span id="pvAnnM"></span></div>
                    <div class="vzp-card" data-card><div><strong>Survival SMP</strong><div style="color:var(--p-tx2)">10.0.0.1:25565</div></div><span class="vzp-dot"></span></div>
                    <div class="vzp-card" data-card><div><strong>Creative Hub</strong><div style="color:var(--p-tx2)">10.0.0.1:25566</div></div><span class="vzp-dot"></span></div>
                    <span class="vzp-btn">Primary action</span>
                </div>
            </div>
            <p class="vz-ap-note">The preview is a simplified sketch. Save, then open the panel to see the real thing.</p>
        </div>
    </div>
@endsection

@section('footer-scripts')
    @parent
    <script>
        (function () {
            var S = {!! json_encode($settings, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES) !!};
            var CSRF = '{{ csrf_token() }}';
            var URL_ = '{{ route('admin.vizion') }}';
            var ACCENTS = [['Azure', '#4F8CFF'], ['Indigo', '#7C83FF'], ['Violet', '#A07CFF'], ['Rose', '#F2638A'], ['Amber', '#E8A33D'], ['Emerald', '#2FBF8C'], ['Teal', '#27B5C9'], ['Graphite', '#9AA4B5']];
            var ICONS = ['chat', 'support', 'docs', 'status', 'web', 'store'];
            var $ = function (s, r) { return (r || document).querySelector(s); }, $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
            var get = function (p) { return p.split('.').reduce(function (o, k) { return o == null ? o : o[k]; }, S); };
            var put = function (p, v) { var k = p.split('.'), last = k.pop(), o = k.reduce(function (a, b) { return a[b]; }, S); o[last] = v; };
            var statusEl = $('#status');
            var say = function (t, cls) { statusEl.textContent = t; statusEl.className = 'vz-ap-status ' + (cls || ''); };
            var esc = function (t) { var d = document.createElement('div'); d.textContent = t; return d.innerHTML; };

            // ---- tabs
            $$('[data-tab]').forEach(function (b) {
                b.addEventListener('click', function () {
                    $$('[data-tab]').forEach(function (x) { x.setAttribute('aria-selected', x === b ? 'true' : 'false'); });
                    $$('[data-pane]').forEach(function (p) { p.classList.toggle('on', p.getAttribute('data-pane') === b.getAttribute('data-tab')); });
                });
            });

            // ---- swatches
            var sw = $('#swatches');
            ACCENTS.forEach(function (a) {
                var b = document.createElement('button');
                b.type = 'button'; b.title = a[0]; b.setAttribute('aria-label', a[0]); b.style.background = a[1]; b.setAttribute('data-hex', a[1]);
                b.addEventListener('click', function () { put('appearance.accent', a[1]); sync(); });
                sw.appendChild(b);
            });

            // ---- generic bindings
            $$('[data-k]').forEach(function (el) {
                var path = el.getAttribute('data-k'), t = el.getAttribute('data-t');
                el.addEventListener('input', function () {
                    var v = t === 'bool' ? el.checked : t === 'num' ? Number(el.value) : el.value;
                    if (path === 'appearance.accent' && !/^#[0-9a-f]{6}$/i.test(String(v))) return;
                    put(path, v); sync(el);
                });
            });
            $$('[data-seg]').forEach(function (g) {
                $$('button', g).forEach(function (b) { b.addEventListener('click', function () { put(g.getAttribute('data-seg'), b.getAttribute('data-v')); sync(); }); });
            });
            $$('[data-clear]').forEach(function (b) { b.addEventListener('click', function () { put(b.getAttribute('data-clear'), ''); sync(); }); });

            // ---- image upload (shrinks big pictures first)
            var shrink = function (file, max) {
                return new Promise(function (resolve) {
                    var img = new Image(), u = URL.createObjectURL(file);
                    img.onerror = function () { resolve(file); };
                    img.onload = function () {
                        var k = Math.min(1, max / Math.max(img.width, img.height)), c = document.createElement('canvas');
                        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
                        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
                        c.toBlob(function (b) { URL.revokeObjectURL(u); resolve(b || file); }, 'image/jpeg', 0.85);
                    };
                    img.src = u;
                });
            };
            $$('[data-upload]').forEach(function (inp) {
                inp.addEventListener('change', function () {
                    var file = inp.files && inp.files[0], target = inp.getAttribute('data-upload');
                    if (!file) return;
                    say('Uploading…');
                    shrink(file, target === 'cards' ? 1280 : 1920).then(function (blob) {
                        var fd = new FormData(); fd.append('image', blob, 'upload.jpg'); fd.append('target', target);
                        return fetch(URL_ + '/background', { method: 'POST', headers: { 'X-CSRF-TOKEN': CSRF, 'Accept': 'application/json' }, body: fd, credentials: 'same-origin' });
                    }).then(function (r) { return r.json().then(function (j) { if (!r.ok) throw j; return j; }); }).then(function (j) {
                        if (target === 'cards') { put('cards.image', j.url); put('cards.enabled', true); } else { put('appearance.bgImage', j.url); put('appearance.bg', 'image'); }
                        say('Uploaded. Press "Save for everyone" to publish it.', 'ok'); sync();
                    }).catch(function (e) { say((e && e.message) || 'Upload failed. Check that public/vizion is writable.', 'err'); });
                    inp.value = '';
                });
            });

            // ---- links editor
            var rows = $('#linkRows');
            var drawLinks = function () {
                rows.innerHTML = '';
                S.links.items.forEach(function (it, i) {
                    var d = document.createElement('div'); d.className = 'vz-ap-link';
                    d.innerHTML = '<input class="form-control" data-f="label" maxlength="40" placeholder="Label" value="' + esc(it.label).replace(/"/g, '&quot;') + '">' +
                        '<input class="form-control" data-f="url" maxlength="300" placeholder="https://…" value="' + esc(it.url).replace(/"/g, '&quot;') + '">' +
                        '<select class="form-control" data-f="icon">' + ICONS.map(function (n) { return '<option value="' + n + '"' + (n === it.icon ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select>' +
                        '<label class="vz-ap-check"><input type="checkbox" data-f="enabled"' + (it.enabled ? ' checked' : '') + '> On</label>' +
                        '<button type="button" class="btn btn-default" data-rm="' + i + '" aria-label="Remove link">&times;</button>';
                    $$('[data-f]', d).forEach(function (f) {
                        f.addEventListener('input', function () { S.links.items[i][f.getAttribute('data-f')] = f.type === 'checkbox' ? f.checked : f.value; preview(); });
                    });
                    $('[data-rm]', d).addEventListener('click', function () { S.links.items.splice(i, 1); drawLinks(); preview(); });
                    rows.appendChild(d);
                });
            };
            var addLink = function (label, icon) {
                if (S.links.items.length >= 8) return say('You can add up to 8 links.', 'err');
                S.links.items.push({ label: label || '', url: '', icon: icon || 'web', enabled: true }); S.links.enabled = true; drawLinks(); sync();
            };
            $('#addLink').addEventListener('click', function () { addLink('', 'web'); });
            $$('[data-preset]').forEach(function (b) { b.addEventListener('click', function () { var p = b.getAttribute('data-preset').split('|'); addLink(p[0], p[1]); }); });

            // ---- preview + control sync
            var preview = function () {
                var A = S.appearance, pv = $('#preview'), mode = A.mode === 'system' ? (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark') : A.mode;
                pv.setAttribute('data-m', mode);
                var n = parseInt(String(A.accent).slice(1), 16);
                pv.style.setProperty('--vz-accent', A.accent); pv.style.setProperty('--vz-acc-rgb', [(n >> 16) & 255, (n >> 8) & 255, n & 255].join(','));
                pv.style.setProperty('--a-r', A.radius + 'px'); pv.style.setProperty('--a-r-lg', Math.round(A.radius * 1.4) + 'px');
                var st = $('#pvStage'), dim = $('#pvDim'); st.style.cssText = ''; dim.style.cssText = '';
                if (A.bg === 'color') st.style.background = A.bgColor;
                else if (A.bg === 'gradient') st.style.background = 'linear-gradient(' + A.bgGradient.angle + 'deg,' + A.bgGradient.from + ',' + A.bgGradient.to + ')';
                else if (A.bg === 'image' && A.bgImage) { st.style.background = 'url("' + A.bgImage + '") center/cover'; st.style.filter = 'blur(' + A.bgBlur + 'px)'; st.style.transform = 'scale(1.06)'; dim.style.background = 'rgba(0,0,0,' + (A.bgDim / 100) + ')'; }
                else if (A.bg === 'dots') st.style.backgroundImage = 'radial-gradient(rgba(var(--p-ov),.12) 1px, transparent 1px)', st.style.backgroundSize = '14px 14px';
                else if (A.bg === 'glow') st.style.background = 'radial-gradient(60% 50% at 20% 0%, rgba(var(--vz-acc-rgb),.25), transparent 70%)';
                var an = S.announcement, box = $('#pvAnn');
                box.className = 'vzp-ann' + (an.enabled && (an.title || an.message) ? ' on' : ''); box.setAttribute('data-t', an.type);
                $('#pvAnnT').textContent = an.title; $('#pvAnnM').textContent = an.message;
                $('#pvLinks').innerHTML = S.links.enabled ? S.links.items.filter(function (l) { return l.enabled && l.label; }).map(function (l) { return '<em>' + esc(l.label) + '</em>'; }).join('') : '';
                $$('[data-card]').forEach(function (c) {
                    var on = S.cards.enabled && S.cards.image; c.classList.toggle('pic', !!on);
                    if (on) { c.style.setProperty('--p-card', 'url("' + S.cards.image + '")'); c.style.setProperty('--p-dim', S.cards.dim / 100); c.style.setProperty('--p-blur', S.cards.blur + 'px'); }
                });
            };
            var sync = function (skip) {
                $$('[data-k]').forEach(function (el) {
                    if (el === skip) return;
                    var v = get(el.getAttribute('data-k'));
                    if (el.type === 'checkbox') el.checked = !!v; else if (el.value !== String(v == null ? '' : v)) el.value = v == null ? '' : v;
                });
                $$('[data-seg]').forEach(function (g) { var cur = get(g.getAttribute('data-seg')); $$('button', g).forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-v') === cur ? 'true' : 'false'); }); });
                $$('[data-show]').forEach(function (b) { var p = b.getAttribute('data-show').split('='); b.style.display = String(get(p[0])) === p[1] ? '' : 'none'; });
                $$('[data-out]').forEach(function (o) { var p = o.getAttribute('data-out'), v = get(p); o.textContent = v + (p.indexOf('radius') > -1 || p.indexOf('Blur') > -1 || p.indexOf('blur') > -1 ? 'px' : '%'); });
                $$('#swatches button').forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-hex').toLowerCase() === String(S.appearance.accent).toLowerCase() ? 'true' : 'false'); });
                $('#accentLabel').textContent = String(S.appearance.accent).toUpperCase();
                preview();
            };

            // ---- save / reset
            var errText = function (j) { if (j && j.errors) { var f = Object.keys(j.errors)[0]; return j.errors[f][0]; } return (j && j.message) || 'Could not save.'; };
            $('#save').addEventListener('click', function () {
                say('Saving…');
                fetch(URL_, { method: 'POST', headers: { 'X-CSRF-TOKEN': CSRF, 'Accept': 'application/json', 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify(S) })
                    .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw j; return j; }); })
                    .then(function () { say('Saved. Everyone sees it on their next page load.', 'ok'); })
                    .catch(function (e) { say(errText(e), 'err'); });
            });
            $('#reset').addEventListener('click', function () {
                if (!window.confirm('Reset the look, banner and links to the defaults for everyone?')) return;
                fetch(URL_, { method: 'DELETE', headers: { 'X-CSRF-TOKEN': CSRF, 'Accept': 'application/json' }, credentials: 'same-origin' })
                    .then(function (r) { return r.json(); }).then(function (j) { S = j; drawLinks(); sync(); say('Back to the defaults.', 'ok'); })
                    .catch(function () { say('Could not reset.', 'err'); });
            });

            drawLinks(); sync();
        })();
    </script>
@endsection
