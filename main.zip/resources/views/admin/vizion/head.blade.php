{{-- Vizion: admin theme. Included once at the end of <head> in layouts/admin.blade.php by the installer. --}}
@php
    $vzFile = storage_path('app/vizion/settings.json');
    $vzAll = is_file($vzFile) ? json_decode((string) @file_get_contents($vzFile), true) : [];
    $vzA = is_array($vzAll) && is_array($vzAll['appearance'] ?? null) ? $vzAll['appearance'] : [];
    $vzMode = in_array($vzA['mode'] ?? 'dark', ['system', 'light', 'dark', 'oled'], true) ? ($vzA['mode'] ?? 'dark') : 'dark';
    $vzAccent = preg_match('/^#[0-9a-fA-F]{6}$/', (string) ($vzA['accent'] ?? '')) ? $vzA['accent'] : '#4F8CFF';
    $vzRadius = max(2, min(20, (int) ($vzA['radius'] ?? 10)));
    $vzCss = public_path('themes/vizion/admin.css');
@endphp
@if (is_file($vzCss))
    <link rel="stylesheet" href="/themes/vizion/admin.css?v={{ filemtime($vzCss) }}">
    <style>:root { --vz-accent: {{ $vzAccent }}; --vz-radius: {{ $vzRadius }}px; }</style>
    <script>
        (function () {
            var m = '{{ $vzMode }}', h = '{{ $vzAccent }}', n = parseInt(h.slice(1), 16);
            if (m === 'system') m = matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
            document.documentElement.setAttribute('data-vz-mode', m);
            document.documentElement.style.setProperty('--vz-acc-rgb', [(n >> 16) & 255, (n >> 8) & 255, n & 255].join(','));
        })();
    </script>
@endif
