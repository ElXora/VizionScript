/**
 * Vizion appearance engine.
 * Takes the look the administrator saved (Admin → Appearance, embedded in the page as window.VizionSettings)
 * and writes it to <html> as data-attributes and CSS variables.
 * Everything visual (modes, accent ramp, background, radius ...) is driven from here, nothing is baked into the build.
 */
export type Mode = 'system' | 'light' | 'dark' | 'oled';
export type Background = 'dots' | 'glow' | 'plain' | 'color' | 'gradient' | 'image';

export interface Appearance {
    mode: Mode;
    accent: string;
    radius: number;
    density: 'comfortable' | 'compact';
    font: 'default' | 'system' | 'plex';
    motion: 'full' | 'reduced';
    bg: Background;
    bgColor: string;
    bgGradient: { from: string; to: string; angle: number };
    bgImage: string;
    bgBlur: number;
    bgDim: number;
}

export const DEFAULTS: Appearance = {
    mode: 'dark',
    accent: '#4F8CFF',
    radius: 10,
    density: 'comfortable',
    font: 'default',
    motion: 'full',
    bg: 'dots',
    bgColor: '#0A0E14',
    bgGradient: { from: '#0A0E14', to: '#14213A', angle: 160 },
    bgImage: '',
    bgBlur: 0,
    bgDim: 55,
};

export const ACCENTS: { name: string; value: string }[] = [
    { name: 'Azure', value: '#4F8CFF' },
    { name: 'Indigo', value: '#7C83FF' },
    { name: 'Violet', value: '#A07CFF' },
    { name: 'Rose', value: '#F2638A' },
    { name: 'Amber', value: '#E8A33D' },
    { name: 'Emerald', value: '#2FBF8C' },
    { name: 'Teal', value: '#27B5C9' },
    { name: 'Graphite', value: '#9AA4B5' },
];

let current: Appearance = { ...DEFAULTS };

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, Number.isFinite(n) ? n : lo));
/** Number from stored/pasted JSON, falling back to the default when it is missing or not a number. */
const num = (v: unknown, d: number, lo: number, hi: number) => (v === undefined || v === null || v === '' || !Number.isFinite(Number(v)) ? d : clamp(Number(v), lo, hi));
const isHex = (v: unknown): v is string => typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v);

/** Accepts anything (stored JSON, pasted JSON) and returns a safe, complete Appearance. */
export const sanitize = (raw: any): Appearance => {
    const r = raw && typeof raw === 'object' ? raw : {};
    const one = <T extends string>(v: any, all: T[], d: T): T => (all.includes(v) ? v : d);
    return {
        mode: one(r.mode, ['system', 'light', 'dark', 'oled'], DEFAULTS.mode),
        accent: isHex(r.accent) ? r.accent : DEFAULTS.accent,
        radius: num(r.radius, DEFAULTS.radius, 2, 20),
        density: one(r.density, ['comfortable', 'compact'], DEFAULTS.density),
        font: one(r.font, ['default', 'system', 'plex'], DEFAULTS.font),
        motion: one(r.motion, ['full', 'reduced'], DEFAULTS.motion),
        bg: one(r.bg, ['dots', 'glow', 'plain', 'color', 'gradient', 'image'], DEFAULTS.bg),
        bgColor: isHex(r.bgColor) ? r.bgColor : DEFAULTS.bgColor,
        bgGradient: {
            from: isHex(r.bgGradient?.from) ? r.bgGradient.from : DEFAULTS.bgGradient.from,
            to: isHex(r.bgGradient?.to) ? r.bgGradient.to : DEFAULTS.bgGradient.to,
            angle: num(r.bgGradient?.angle, DEFAULTS.bgGradient.angle, 0, 360),
        },
        bgImage: typeof r.bgImage === 'string' && /^(https?:\/\/|\/)[^\s"'<>\\]*$/i.test(r.bgImage) ? r.bgImage : '',
        bgBlur: num(r.bgBlur, DEFAULTS.bgBlur, 0, 24),
        bgDim: num(r.bgDim, DEFAULTS.bgDim, 0, 90),
    };
};

/* ------------------------------------------------------------------ colour helpers */
const hexToRgb = (h: string): [number, number, number] => {
    const n = parseInt(h.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const rgbToHsl = (r: number, g: number, b: number): [number, number, number] => {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
    let h = 0, s = 0;
    if (d) {
        s = d / (1 - Math.abs(2 * l - 1));
        h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
        h = (h * 60 + 360) % 360;
    }
    return [h, s, l];
};
const hslToHex = (h: number, s: number, l: number): string => {
    const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = l - c / 2;
    const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
    return '#' + [r, g, b].map((v) => Math.round((v + m) * 255).toString(16).padStart(2, '0')).join('');
};
const luminance = (hex: string) => {
    const [r, g, b] = hexToRgb(hex).map((v) => {
        v /= 255;
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
};

/** Builds a 50..900 ramp around the chosen accent (which becomes shade 500). */
export const accentRamp = (hex: string): Record<number, string> => {
    const [h, s, l0] = rgbToHsl(...hexToRgb(hex));
    const base = clamp(l0, 0.42, 0.66);
    const ls: Record<number, number> = { 50: 0.96, 100: 0.92, 200: 0.84, 300: 0.75, 400: Math.min(0.78, base + 0.08), 500: base, 600: base - 0.07, 700: base - 0.15, 800: base - 0.23, 900: base - 0.3 };
    const out: Record<number, string> = {};
    Object.keys(ls).forEach((k) => {
        const n = Number(k);
        out[n] = n === 500 ? hslToHex(h, s, base) : hslToHex(h, n <= 100 ? s * 0.8 : s, clamp(ls[n], 0.08, 0.97));
    });
    // very light accents need dark text on top of them (button text uses shade 50)
    if (luminance(out[500]) > 0.38) out[50] = '#0B1220';
    return out;
};

/* ------------------------------------------------------------------ applying */
const mq = typeof window !== 'undefined' && window.matchMedia ? window.matchMedia('(prefers-color-scheme: light)') : null;
export const resolveMode = (m: Mode): 'light' | 'dark' | 'oled' => (m === 'system' ? (mq && mq.matches ? 'light' : 'dark') : m);
const THEME_COLOR = { light: '#F1F3F7', dark: '#0A0E14', oled: '#000000' };

export const apply = (a: Appearance) => {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    const mode = resolveMode(a.mode);
    root.setAttribute('data-vz-mode', mode);
    root.setAttribute('data-vz-pref', a.mode);
    root.setAttribute('data-vz-bg', a.bg);
    root.setAttribute('data-vz-density', a.density);
    root.setAttribute('data-vz-font', a.font);
    root.setAttribute('data-vz-motion', a.motion);

    const ramp = accentRamp(a.accent);
    Object.keys(ramp).forEach((k) => root.style.setProperty(`--vz-p${k}`, ramp[Number(k)]));
    const [r, g, b] = hexToRgb(ramp[500]);
    root.style.setProperty('--vz-accent', ramp[500]);
    root.style.setProperty('--vz-accent-h', ramp[400]);
    root.style.setProperty('--vz-acc-rgb', `${r}, ${g}, ${b}`);

    root.style.setProperty('--vz-radius', `${a.radius}px`);
    root.style.setProperty('--vz-bg-color', a.bgColor);
    root.style.setProperty('--vz-bg-grad', `linear-gradient(${a.bgGradient.angle}deg, ${a.bgGradient.from}, ${a.bgGradient.to})`);
    root.style.setProperty('--vz-bg-image', a.bgImage ? `url("${a.bgImage.replace(/"/g, '%22')}")` : 'none');
    root.style.setProperty('--vz-bg-blur', `${a.bgBlur}px`);
    root.style.setProperty('--vz-bg-dim', String(a.bgDim / 100));

    const meta = document.querySelector('meta[name=theme-color]') as HTMLMetaElement | null;
    if (meta) meta.content = THEME_COLOR[mode];
};

/** Optional picture behind every server card on the dashboard (Admin → Appearance → Server cards). */
export const applyCards = () => {
    if (typeof document === 'undefined') return;
    const raw = (window as any).VizionSettings?.cards || {};
    const image = typeof raw.image === 'string' && /^(https?:\/\/|\/)[^\s"'<>\\]*$/i.test(raw.image) ? raw.image : '';
    const root = document.documentElement;
    root.setAttribute('data-vz-cards', raw.enabled === true && image ? '1' : '0');
    root.style.setProperty('--vz-card-image', image ? `url("${image.replace(/"/g, '%22')}")` : 'none');
    root.style.setProperty('--vz-card-dim', String(num(raw.dim, 70, 40, 95) / 100));
    root.style.setProperty('--vz-card-blur', `${num(raw.blur, 0, 0, 12)}px`);
};

/** The look every user receives: whatever the administrator saved under Admin → Appearance. */
export const load = (): Appearance => sanitize((typeof window !== 'undefined' && (window as any).VizionSettings?.appearance) || {});

export const get = () => current;

/** Reads a CSS variable at call time (canvas charts cannot use var()). */
export const cssVar = (name: string, fallback: string): string => {
    if (typeof document === 'undefined') return fallback;
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;
};

// run once on import, before the first paint of the React app
if (typeof window !== 'undefined') {
    current = load();
    apply(current);
    applyCards();
    if (mq && mq.addEventListener) {
        mq.addEventListener('change', () => current.mode === 'system' && apply(current));
    }
}
