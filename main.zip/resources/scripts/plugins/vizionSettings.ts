/**
 * Announcement banner + quick links, configured by administrators under Admin → Appearance.
 * The server embeds the saved values as window.VizionSettings; nothing here talks to the API.
 */
export type AnnouncementType = 'info' | 'success' | 'warning' | 'danger';
export type LinkIcon = 'chat' | 'support' | 'docs' | 'status' | 'web' | 'store';

export interface Announcement {
    enabled: boolean;
    type: AnnouncementType;
    title: string;
    message: string;
    linkLabel: string;
    linkUrl: string;
    dismissible: boolean;
    rev: number;
}
export interface QuickLink {
    label: string;
    url: string;
    icon: LinkIcon;
    enabled: boolean;
}
export interface VizionExtras {
    announcement: Announcement;
    links: { enabled: boolean; items: QuickLink[] };
}

/** Only web links, mail links and same-site paths are allowed (blocks javascript: and friends). */
export const safeUrl = (u: unknown): string => (typeof u === 'string' && /^(https?:\/\/|mailto:|\/(?!\/))[^\s"'<>\\]*$/i.test(u) ? u : '');

const text = (v: unknown, max: number) => (typeof v === 'string' ? v.slice(0, max) : '');
const pick = <T extends string>(v: unknown, all: T[], d: T): T => (all.includes(v as T) ? (v as T) : d);

export const readExtras = (): VizionExtras => {
    const raw: any = (typeof window !== 'undefined' && (window as any).VizionSettings) || {};
    const a = raw.announcement || {};
    const l = raw.links || {};
    const items: QuickLink[] = (Array.isArray(l.items) ? l.items : [])
        .slice(0, 8)
        .map((i: any) => ({
            label: text(i?.label, 40),
            url: safeUrl(i?.url),
            icon: pick<LinkIcon>(i?.icon, ['chat', 'support', 'docs', 'status', 'web', 'store'], 'web'),
            enabled: i?.enabled === true,
        }))
        .filter((i: QuickLink) => i.label && i.url);

    return {
        announcement: {
            enabled: a.enabled === true,
            type: pick<AnnouncementType>(a.type, ['info', 'success', 'warning', 'danger'], 'info'),
            title: text(a.title, 80),
            message: text(a.message, 400),
            linkLabel: text(a.linkLabel, 40),
            linkUrl: safeUrl(a.linkUrl),
            dismissible: a.dismissible !== false,
            rev: Number.isFinite(Number(a.rev)) ? Number(a.rev) : 0,
        },
        links: { enabled: l.enabled === true, items },
    };
};
