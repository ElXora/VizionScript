import React, { forwardRef } from 'react';
import { Form } from 'formik';
import { useStoreState } from 'easy-peasy';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBook, faComments, faGlobe, faHeadset, faHeartbeat, faShoppingCart } from '@fortawesome/free-solid-svg-icons';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import { ApplicationStore } from '@/state';
import FlashMessageRender from '@/components/FlashMessageRender';
import { LinkIcon, readBranding, readExtras } from '@/plugins/vizionSettings';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

const ICONS: Record<LinkIcon, IconDefinition> = {
    chat: faComments,
    support: faHeadset,
    docs: faBook,
    status: faHeartbeat,
    web: faGlobe,
    store: faShoppingCart,
};

export default forwardRef<HTMLFormElement, Props>(({ title, className, children, ...props }, ref) => {
    const name = useStoreState((state: ApplicationStore) => state.settings.data!.name);
    const { links } = readExtras();
    const brand = readBranding();
    const items = links.enabled ? links.items.filter((l) => l.enabled) : [];

    return (
        <div className={'vz-auth'}>
            <header className={'vz-auth-top'}>
                <a href={'/'} className={'vz-auth-brand'}>
                    <i className={'vz-auth-logo' + (brand.logo ? ' vz-custom' : '')}>
                        <img src={brand.logo || '/assets/svgs/pterodactyl.svg'} alt={''} />
                    </i>
                    {brand.showName && <span>{name}</span>}
                </a>
                {items.length > 0 && (
                    <nav className={'vz-auth-links'} aria-label={'Links'}>
                        {items.map((l) => (
                            <a key={l.label + l.url} href={l.url} target={'_blank'} rel={'noopener noreferrer'}>
                                <FontAwesomeIcon icon={ICONS[l.icon]} />
                                <span>{l.label}</span>
                            </a>
                        ))}
                    </nav>
                )}
            </header>
            <main className={'vz-auth-main'}>
                <div className={'vz-auth-card'}>
                    {title && <h2>{title}</h2>}
                    <FlashMessageRender className={'vz-auth-flash'} />
                    <Form {...props} ref={ref} className={'vz-auth-form'}>
                        {children}
                    </Form>
                </div>
                <p className={'vz-auth-foot'}>
                    &copy; 2015 - {new Date().getFullYear()}&nbsp;
                    <a rel={'noopener nofollow noreferrer'} href={'https://pterodactyl.io'} target={'_blank'}>
                        Pterodactyl Software
                    </a>
                </p>
            </main>
        </div>
    );
});
