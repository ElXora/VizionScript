import * as React from 'react';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faAngleDoubleLeft,
    faBars,
    faCogs,
    faLayerGroup,
    faSignOutAlt,
    faTimes,
    faUserCircle,
} from '@fortawesome/free-solid-svg-icons';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import SearchContainer from '@/components/dashboard/search/SearchContainer';
import http from '@/api/http';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import Tooltip from '@/components/elements/tooltip/Tooltip';
import Avatar from '@/components/Avatar';

const STORAGE_KEY = 'vizion:sidebar-collapsed';

const crumbsFor = (pathname: string): { label: string; to?: string }[] => {
    if (pathname.startsWith('/account')) {
        const sub = pathname.replace('/account', '').replace(/^\//, '');
        const labels: Record<string, string> = { api: 'API credentials', ssh: 'SSH keys', activity: 'Activity' };
        return [{ label: 'Account', to: '/account' }, ...(sub && labels[sub] ? [{ label: labels[sub] }] : [])];
    }
    if (pathname.startsWith('/server/')) {
        return [{ label: 'Servers', to: '/' }, { label: 'Manage server' }];
    }
    return [{ label: 'Servers' }];
};

export default () => {
    const location = useLocation();
    const name = useStoreState((state: ApplicationStore) => state.settings.data!.name);
    const rootAdmin = useStoreState((state: ApplicationStore) => state.user.data!.rootAdmin);
    const user = useStoreState((state: ApplicationStore) => state.user.data);
    const [isLoggingOut, setIsLoggingOut] = useState(false);
    const [open, setOpen] = useState(false);
    const [collapsed, setCollapsed] = useState(() => {
        try {
            return window.localStorage.getItem(STORAGE_KEY) === '1';
        } catch (e) {
            return false;
        }
    });
    const navRef = useRef<HTMLElement>(null);
    const [indicator, setIndicator] = useState({ y: 0, h: 0, show: false });

    const onTriggerLogout = () => {
        setIsLoggingOut(true);
        http.post('/auth/logout').finally(() => {
            // @ts-expect-error this is valid
            window.location = '/';
        });
    };

    // The sidebar is fixed, so the page needs to know to leave room for it.
    useEffect(() => {
        document.documentElement.classList.add('vz-shell');
        return () => document.documentElement.classList.remove('vz-shell');
    }, []);

    useEffect(() => {
        document.documentElement.setAttribute('data-vz-collapsed', collapsed ? '1' : '0');
        try {
            window.localStorage.setItem(STORAGE_KEY, collapsed ? '1' : '0');
        } catch (e) {
            // storage unavailable, preference simply is not remembered
        }
    }, [collapsed]);

    useEffect(() => setOpen(false), [location.pathname]);

    useEffect(() => {
        if (!open) return;
        const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, [open]);

    // Slide the active indicator to the current item.
    useLayoutEffect(() => {
        const nav = navRef.current;
        const active = nav && (nav.querySelector('.vz-item.active') as HTMLElement | null);
        if (!nav || !active) return setIndicator((i) => ({ ...i, show: false }));
        setIndicator({ y: active.offsetTop, h: active.offsetHeight, show: true });
    }, [location.pathname, collapsed, rootAdmin]);

    const onServerPage = location.pathname.startsWith('/server');
    const crumbs = crumbsFor(location.pathname);

    const item = (label: string, icon: IconDefinition, el: (cls: string, children: React.ReactNode) => React.ReactElement) => (
        <Tooltip placement={'right'} content={label} disabled={!collapsed}>
            {el(
                'vz-item',
                <>
                    <FontAwesomeIcon icon={icon} fixedWidth />
                    <span>{label}</span>
                </>
            )}
        </Tooltip>
    );

    return (
        <>
            <SpinnerOverlay visible={isLoggingOut} />
            <aside className={'vz-side'} data-open={open ? '1' : '0'} aria-label={'Primary'}>
                <div className={'vz-side-head'}>
                    <Link to={'/'} className={'vz-brand'}>
                        <img src={'/assets/svgs/pterodactyl.svg'} alt={''} />
                        <span>{name}</span>
                    </Link>
                    <button type={'button'} className={'vz-icon-btn vz-only-mobile'} onClick={() => setOpen(false)} aria-label={'Close menu'}>
                        <FontAwesomeIcon icon={faTimes} />
                    </button>
                </div>
                <nav ref={navRef} className={'vz-nav'}>
                    <span
                        className={'vz-ind'}
                        style={{ transform: `translateY(${indicator.y}px)`, height: indicator.h, opacity: indicator.show ? 1 : 0 }}
                    />
                    <p className={'vz-nav-label'}>Platform</p>
                    {item('Servers', faLayerGroup, (cls, children) => (
                        <NavLink to={'/'} exact className={cls} isActive={() => location.pathname === '/' || onServerPage}>
                            {children}
                        </NavLink>
                    ))}
                    {item('Account', faUserCircle, (cls, children) => (
                        <NavLink to={'/account'} className={cls}>
                            {children}
                        </NavLink>
                    ))}
                    {rootAdmin &&
                        item('Admin', faCogs, (cls, children) => (
                            <a href={'/admin'} rel={'noreferrer'} className={cls}>
                                {children}
                            </a>
                        ))}
                </nav>
                <div className={'vz-side-foot'}>
                    <div className={'vz-user'}>
                        <span className={'vz-avatar'}>
                            <Avatar.User />
                        </span>
                        <div className={'vz-user-meta'}>
                            <p>{user?.username}</p>
                            <small>{rootAdmin ? 'Administrator' : 'User'}</small>
                        </div>
                        <Tooltip placement={'top'} content={'Sign out'}>
                            <button type={'button'} className={'vz-icon-btn'} onClick={onTriggerLogout} aria-label={'Sign out'}>
                                <FontAwesomeIcon icon={faSignOutAlt} />
                            </button>
                        </Tooltip>
                    </div>
                    <button
                        type={'button'}
                        className={'vz-collapse vz-only-desktop'}
                        onClick={() => setCollapsed((c) => !c)}
                        aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
                    >
                        <FontAwesomeIcon icon={faAngleDoubleLeft} />
                        <span>Collapse</span>
                    </button>
                </div>
            </aside>
            <div className={'vz-scrim'} data-open={open ? '1' : '0'} onClick={() => setOpen(false)} />
            <header className={'vz-topbar'}>
                <button type={'button'} className={'vz-icon-btn vz-only-mobile'} onClick={() => setOpen(true)} aria-label={'Open menu'} aria-expanded={open}>
                    <FontAwesomeIcon icon={faBars} />
                </button>
                <ol className={'vz-crumbs'}>
                    {crumbs.map((c, i) => (
                        <li key={c.label} aria-current={i === crumbs.length - 1 ? 'page' : undefined}>
                            {c.to && i < crumbs.length - 1 ? <Link to={c.to}>{c.label}</Link> : <span>{c.label}</span>}
                        </li>
                    ))}
                </ol>
                <div className={'vz-topbar-actions'}>
                    <SearchContainer />
                </div>
            </header>
        </>
    );
};
