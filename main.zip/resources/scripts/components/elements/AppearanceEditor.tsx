import * as React from 'react';
import { useEffect, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircle, faCopy, faDesktop, faImage, faMoon, faPaste, faSun, faTimes, faTrashAlt, faUndo, faUpload } from '@fortawesome/free-solid-svg-icons';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import { ACCENTS, Appearance, Background, Mode, exportJson, importJson, imageToDataUrl, reset, set, useAppearance } from '@/plugins/appearance';

interface Props {
    open: boolean;
    onClose: () => void;
}

const MODES: { id: Mode; label: string; icon: IconDefinition }[] = [
    { id: 'system', label: 'System', icon: faDesktop },
    { id: 'light', label: 'Light', icon: faSun },
    { id: 'dark', label: 'Dark', icon: faMoon },
    { id: 'oled', label: 'OLED', icon: faCircle },
];
const BACKGROUNDS: { id: Background; label: string }[] = [
    { id: 'dots', label: 'Dots' },
    { id: 'glow', label: 'Glow' },
    { id: 'plain', label: 'Plain' },
    { id: 'color', label: 'Color' },
    { id: 'gradient', label: 'Gradient' },
    { id: 'image', label: 'Image' },
];

const Seg = <T extends string>({ value, items, onPick }: { value: T; items: { id: T; label: string; icon?: IconDefinition }[]; onPick: (v: T) => void }) => (
    <div className={'vz-seg'} role={'group'}>
        {items.map((i) => (
            <button key={i.id} type={'button'} aria-pressed={value === i.id} onClick={() => onPick(i.id)}>
                {i.icon && <FontAwesomeIcon icon={i.icon} />}
                {i.label}
            </button>
        ))}
    </div>
);

export default ({ open, onClose }: Props) => {
    const a: Appearance = useAppearance();
    const fileRef = useRef<HTMLInputElement>(null);
    const [msg, setMsg] = useState<{ text: string; err?: boolean } | null>(null);
    const [paste, setPaste] = useState<string | null>(null);
    const [hex, setHex] = useState(a.accent);

    useEffect(() => setHex(a.accent), [a.accent]);
    useEffect(() => {
        if (!open) return;
        const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, [open]);

    const say = (text: string, err = false) => {
        setMsg({ text, err });
        window.setTimeout(() => setMsg(null), 4200);
    };
    const save = (patch: Partial<Appearance>) => {
        if (!set(patch)) say('Your browser has no room left to remember this. The change works until you reload.', true);
    };

    const onFile = async (file?: File) => {
        if (!file) return;
        try {
            const url = await imageToDataUrl(file);
            save({ bg: 'image', bgImage: url });
            say('Background updated. It is stored in this browser only.');
        } catch (e) {
            say((e as Error).message, true);
        }
    };

    const copy = async () => {
        try {
            await navigator.clipboard.writeText(exportJson());
            say('Settings copied. Paste them on another browser to get the same look.');
        } catch (e) {
            setPaste(exportJson());
        }
    };

    return (
        <aside className={'vz-ae'} data-open={open ? '1' : '0'} aria-hidden={!open} aria-label={'Appearance'}>
            <div className={'vz-ae-head'}>
                <h3>Appearance</h3>
                <button type={'button'} className={'vz-icon-btn'} onClick={onClose} aria-label={'Close appearance editor'}>
                    <FontAwesomeIcon icon={faTimes} />
                </button>
            </div>
            <div className={'vz-ae-body'}>
                <section className={'vz-ae-sec'}>
                    <div className={'vz-ae-lab'}>Mode</div>
                    <Seg value={a.mode} items={MODES} onPick={(mode) => save({ mode })} />
                </section>

                <section className={'vz-ae-sec'}>
                    <div className={'vz-ae-lab'}>
                        Accent <b>{a.accent.toUpperCase()}</b>
                    </div>
                    <div className={'vz-swatches'}>
                        {ACCENTS.map((c) => (
                            <button key={c.value} type={'button'} className={'vz-swatch'} title={c.name} aria-label={c.name} aria-pressed={a.accent.toLowerCase() === c.value.toLowerCase()} style={{ background: c.value }} onClick={() => save({ accent: c.value })} />
                        ))}
                    </div>
                    <div className={'vz-row'}>
                        <input type={'color'} value={a.accent} onChange={(e) => save({ accent: e.target.value })} aria-label={'Pick accent colour'} />
                        <input
                            type={'text'}
                            value={hex}
                            maxLength={7}
                            spellCheck={false}
                            onChange={(e) => {
                                setHex(e.target.value);
                                if (/^#[0-9a-f]{6}$/i.test(e.target.value)) save({ accent: e.target.value });
                            }}
                            aria-label={'Accent hex value'}
                        />
                    </div>
                </section>

                <section className={'vz-ae-sec'}>
                    <div className={'vz-ae-lab'}>Background</div>
                    <div className={'vz-seg'} style={{ gridTemplateColumns: 'repeat(3, 1fr)', gridAutoFlow: 'row' }} role={'group'}>
                        {BACKGROUNDS.map((b) => (
                            <button key={b.id} type={'button'} aria-pressed={a.bg === b.id} onClick={() => save({ bg: b.id })}>
                                {b.label}
                            </button>
                        ))}
                    </div>

                    {a.bg === 'color' && (
                        <div className={'vz-row'}>
                            <input type={'color'} value={a.bgColor} onChange={(e) => save({ bgColor: e.target.value })} aria-label={'Background colour'} />
                            <span className={'vz-ae-note'} style={{ margin: 0 }}>Solid colour behind everything</span>
                        </div>
                    )}

                    {a.bg === 'gradient' && (
                        <>
                            <div className={'vz-row'}>
                                <input type={'color'} value={a.bgGradient.from} onChange={(e) => save({ bgGradient: { ...a.bgGradient, from: e.target.value } })} aria-label={'Gradient start'} />
                                <input type={'color'} value={a.bgGradient.to} onChange={(e) => save({ bgGradient: { ...a.bgGradient, to: e.target.value } })} aria-label={'Gradient end'} />
                                <input type={'range'} min={0} max={360} value={a.bgGradient.angle} onChange={(e) => save({ bgGradient: { ...a.bgGradient, angle: Number(e.target.value) } })} aria-label={'Gradient angle'} />
                                <span className={'vz-ae-lab'} style={{ margin: 0 }}>{a.bgGradient.angle}°</span>
                            </div>
                        </>
                    )}

                    {a.bg === 'image' && (
                        <>
                            <div className={'vz-row'}>
                                <button type={'button'} className={'vz-mini'} onClick={() => fileRef.current?.click()}>
                                    <FontAwesomeIcon icon={faUpload} /> Upload image
                                </button>
                                {a.bgImage && (
                                    <button type={'button'} className={'vz-mini danger'} onClick={() => save({ bgImage: '' })}>
                                        <FontAwesomeIcon icon={faTrashAlt} /> Remove
                                    </button>
                                )}
                                <input ref={fileRef} type={'file'} accept={'image/*'} hidden onChange={(e) => onFile(e.target.files?.[0])} />
                            </div>
                            <div className={'vz-row'}>
                                <input
                                    type={'text'}
                                    placeholder={'…or paste an image link (https://)'}
                                    defaultValue={a.bgImage.startsWith('data:') ? '' : a.bgImage}
                                    onBlur={(e) => e.target.value && save({ bg: 'image', bgImage: e.target.value.trim() })}
                                    aria-label={'Background image URL'}
                                />
                            </div>
                            <div className={'vz-ae-lab'} style={{ marginTop: 14 }}>Blur <b>{a.bgBlur}px</b></div>
                            <input type={'range'} min={0} max={24} value={a.bgBlur} onChange={(e) => save({ bgBlur: Number(e.target.value) })} style={{ width: '100%' }} aria-label={'Background blur'} />
                            <div className={'vz-ae-lab'} style={{ marginTop: 10 }}>Darken <b>{a.bgDim}%</b></div>
                            <input type={'range'} min={0} max={90} value={a.bgDim} onChange={(e) => save({ bgDim: Number(e.target.value) })} style={{ width: '100%' }} aria-label={'Background darkening'} />
                            {!a.bgImage && (
                                <p className={'vz-ae-note'}>
                                    <FontAwesomeIcon icon={faImage} /> Pick a picture. It is resized and kept in this browser only, so each person sets their own.
                                </p>
                            )}
                        </>
                    )}
                </section>

                <section className={'vz-ae-sec'}>
                    <div className={'vz-ae-lab'}>
                        Corner radius <b>{a.radius}px</b>
                    </div>
                    <input type={'range'} min={2} max={20} value={a.radius} onChange={(e) => save({ radius: Number(e.target.value) })} style={{ width: '100%' }} aria-label={'Corner radius'} />
                </section>

                <section className={'vz-ae-sec'}>
                    <div className={'vz-ae-lab'}>Density</div>
                    <Seg value={a.density} items={[{ id: 'comfortable', label: 'Comfortable' }, { id: 'compact', label: 'Compact' }]} onPick={(density) => save({ density })} />
                    <div className={'vz-ae-lab'} style={{ marginTop: 16 }}>Typeface</div>
                    <Seg value={a.font} items={[{ id: 'default', label: 'Default' }, { id: 'system', label: 'System' }, { id: 'plex', label: 'Plex' }]} onPick={(font) => save({ font })} />
                    <div className={'vz-ae-lab'} style={{ marginTop: 16 }}>Motion</div>
                    <Seg value={a.motion} items={[{ id: 'full', label: 'Full' }, { id: 'reduced', label: 'Reduced' }]} onPick={(motion) => save({ motion })} />
                </section>

                <section className={'vz-ae-sec'}>
                    <div className={'vz-ae-lab'}>Share this look</div>
                    <div className={'vz-row'} style={{ marginTop: 0 }}>
                        <button type={'button'} className={'vz-mini'} onClick={copy}>
                            <FontAwesomeIcon icon={faCopy} /> Copy
                        </button>
                        <button type={'button'} className={'vz-mini'} onClick={() => setPaste(paste === null ? '' : null)}>
                            <FontAwesomeIcon icon={faPaste} /> Paste
                        </button>
                    </div>
                    {paste !== null && (
                        <>
                            <textarea value={paste} onChange={(e) => setPaste(e.target.value)} spellCheck={false} placeholder={'Paste settings here'} style={{ marginTop: 10 }} />
                            <div className={'vz-row'}>
                                <button
                                    type={'button'}
                                    className={'vz-mini'}
                                    onClick={() => {
                                        if (importJson(paste)) {
                                            say('Settings applied.');
                                            setPaste(null);
                                        } else say('Those settings could not be read.', true);
                                    }}
                                >
                                    Apply
                                </button>
                            </div>
                        </>
                    )}
                    {msg && <p className={'vz-ae-note' + (msg.err ? ' err' : '')} role={'status'}>{msg.text}</p>}
                </section>
            </div>
            <div className={'vz-ae-foot'}>
                <button type={'button'} className={'vz-mini'} onClick={() => { reset(); say('Back to the default look.'); }}>
                    <FontAwesomeIcon icon={faUndo} /> Reset to default
                </button>
            </div>
        </aside>
    );
};
