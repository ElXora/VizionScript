import * as React from 'react';
import { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBullhorn, faCheckCircle, faExclamationTriangle, faInfoCircle, faTimes } from '@fortawesome/free-solid-svg-icons';
import { readExtras } from '@/plugins/vizionSettings';

const ICONS = { info: faInfoCircle, success: faCheckCircle, warning: faExclamationTriangle, danger: faExclamationTriangle };
const KEY = 'vizion:announcement-dismissed';

export default () => {
    const { announcement: a } = readExtras();
    const [hidden, setHidden] = useState(() => {
        try {
            return a.dismissible && window.localStorage.getItem(KEY) === String(a.rev);
        } catch (e) {
            return false;
        }
    });

    if (!a.enabled || hidden || (!a.title && !a.message)) return null;

    const dismiss = () => {
        setHidden(true);
        try {
            window.localStorage.setItem(KEY, String(a.rev));
        } catch (e) {
            // storage unavailable: it simply shows again on the next visit
        }
    };

    return (
        <div className={'vz-ann'} data-type={a.type} role={'status'}>
            <FontAwesomeIcon icon={a.type === 'info' && !a.title ? faBullhorn : ICONS[a.type]} className={'vz-ann-icon'} />
            <p>
                {a.title && <strong>{a.title}</strong>}
                {a.message && <span>{a.message}</span>}
            </p>
            {a.linkUrl && a.linkLabel && (
                <a href={a.linkUrl} target={'_blank'} rel={'noopener noreferrer'} className={'vz-ann-link'}>
                    {a.linkLabel}
                </a>
            )}
            {a.dismissible && (
                <button type={'button'} className={'vz-icon-btn'} onClick={dismiss} aria-label={'Dismiss announcement'}>
                    <FontAwesomeIcon icon={faTimes} />
                </button>
            )}
        </div>
    );
};
