import React, { memo, useEffect, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEthernet, faHdd, faMemory, faMicrochip, faServer } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerPowerState, ServerStats } from '@/api/server/getServerResourceUsage';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import tw from 'twin.macro';
import GreyRowBox from '@/components/elements/GreyRowBox';
import Spinner from '@/components/elements/Spinner';
import styled from 'styled-components/macro';
import isEqual from 'react-fast-compare';

// Determines if the current value is in an alarm threshold so we can show it in red rather
// than the more faded default style.
const isAlarmState = (current: number, limit: number): boolean => limit > 0 && current / (limit * 1024 * 1024) >= 0.9;

const Icon = memo(
    styled(FontAwesomeIcon)<{ $alarm: boolean }>`
        ${(props) => (props.$alarm ? tw`text-red-400` : tw`text-neutral-500`)};
    `,
    isEqual
);

const IconDescription = styled.p<{ $alarm: boolean }>`
    ${tw`text-sm ml-2`};
    ${(props) => (props.$alarm ? tw`text-white` : tw`text-neutral-400`)};
`;

const StatusIndicatorBox = styled(GreyRowBox)<{ $status: ServerPowerState | undefined }>`
    ${tw`relative`};

    & .status-bar {
        ${tw`w-2 bg-red-500 absolute right-0 z-20 rounded-full m-1 opacity-50 transition-all duration-150`};
        height: calc(100% - 0.5rem);

        ${({ $status }) =>
            !$status || $status === 'offline'
                ? tw`bg-red-500`
                : $status === 'running'
                ? tw`bg-green-500`
                : tw`bg-yellow-500`};
    }

    &:hover .status-bar {
        ${tw`opacity-75`};
    }
`;

type Timer = ReturnType<typeof setInterval>;

// Minecraft servers get the "Come play Minecraft" banner, everything else (Node.js and default) gets the Node.js banner.
const isMinecraft = (server: Server): boolean => {
    const hay = `${server.dockerImage} ${server.invocation} ${server.name}`.toLowerCase();
    return (
        server.eggFeatures.some((f) => ['eula', 'java_version', 'pid_limit'].includes(f)) ||
        /minecraft|java|\.jar|paper|spigot|purpur|bukkit|forge|fabric|velocity|bungee|waterfall/.test(hay)
    );
};

export default ({ server, className }: { server: Server; className?: string }) => {
    const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const [isSuspended, setIsSuspended] = useState(server.status === 'suspended');
    const [stats, setStats] = useState<ServerStats | null>(null);

    const getStats = () =>
        getServerResourceUsage(server.uuid)
            .then((data) => setStats(data))
            .catch((error) => console.error(error));

    useEffect(() => {
        setIsSuspended(stats?.isSuspended || server.status === 'suspended');
    }, [stats?.isSuspended, server.status]);

    useEffect(() => {
        // Don't waste a HTTP request if there is nothing important to show to the user because
        // the server is suspended.
        if (isSuspended) return;

        getStats().then(() => {
            interval.current = setInterval(() => getStats(), 30000);
        });

        return () => {
            interval.current && clearInterval(interval.current);
        };
    }, [isSuspended]);

    const alarms = { cpu: false, memory: false, disk: false };
    if (stats) {
        alarms.cpu = server.limits.cpu === 0 ? false : stats.cpuUsagePercent >= server.limits.cpu * 0.9;
        alarms.memory = isAlarmState(stats.memoryUsageInBytes, server.limits.memory);
        alarms.disk = server.limits.disk === 0 ? false : isAlarmState(stats.diskUsageInBytes, server.limits.disk);
    }

    const pct = (used: number, limitMb: number) => (limitMb === 0 ? 0 : Math.min(100, (used / mbToBytes(limitMb)) * 100));
    const meters = stats
        ? {
              cpu: server.limits.cpu === 0 ? 0 : Math.min(100, (stats.cpuUsagePercent / server.limits.cpu) * 100),
              memory: pct(stats.memoryUsageInBytes, server.limits.memory),
              disk: pct(stats.diskUsageInBytes, server.limits.disk),
          }
        : { cpu: 0, memory: 0, disk: 0 };

    const diskLimit = server.limits.disk !== 0 ? bytesToString(mbToBytes(server.limits.disk)) : 'Unlimited';
    const memoryLimit = server.limits.memory !== 0 ? bytesToString(mbToBytes(server.limits.memory)) : 'Unlimited';
    const cpuLimit = server.limits.cpu !== 0 ? server.limits.cpu + ' %' : 'Unlimited';

    const pctText = (n: number) => `${n.toFixed(n >= 10 || n === 0 ? 0 : 1)}%`;
    const stat = (icon: any, label: string, value: number, alarm: boolean, sub: string) => (
        <div className={'vz-stat'} data-alarm={alarm ? '1' : '0'} title={`${label}: ${sub}`}>
            <div className={'vz-stat-top'}>
                <Icon icon={icon} $alarm={alarm} />
                <span className={'vz-stat-label'}>{label}</span>
                <b>{pctText(value)}</b>
            </div>
            <div className={'vz-meter'}>
                <i style={{ width: `${value}%` }} data-alarm={alarm ? '1' : '0'} />
            </div>
            <small>of {sub}</small>
        </div>
    );

    return (
        <StatusIndicatorBox
            as={Link}
            to={`/server/${server.id}`}
            className={`${className || ''} vz-bigcard`}
            data-kind={isMinecraft(server) ? 'minecraft' : 'nodejs'}
            $status={stats?.status}
        >
            <div className={'vz-card-head'}>
                <div className={'icon'}>
                    <FontAwesomeIcon icon={faServer} />
                </div>
                <div css={tw`min-w-0`}>
                    <p className={'vz-card-name'}>{server.name}</p>
                    {!!server.description && <p className={'vz-card-desc'}>{server.description}</p>}
                </div>
                <p className={'vz-card-ip'}>
                    <FontAwesomeIcon icon={faEthernet} />{' '}
                    {server.allocations
                        .filter((alloc) => alloc.isDefault)
                        .map((allocation) => (
                            <React.Fragment key={allocation.ip + allocation.port.toString()}>
                                {allocation.alias || ip(allocation.ip)}:{allocation.port}
                            </React.Fragment>
                        ))}
                </p>
            </div>
            <div className={'vz-card-stats'}>
                {!stats || isSuspended ? (
                    isSuspended ? (
                        <span css={tw`bg-red-500 rounded px-2 py-1 text-red-100 text-xs`}>
                            {server.status === 'suspended' ? 'Suspended' : 'Connection Error'}
                        </span>
                    ) : server.isTransferring || server.status ? (
                        <span css={tw`bg-neutral-500 rounded px-2 py-1 text-neutral-100 text-xs`}>
                            {server.isTransferring
                                ? 'Transferring'
                                : server.status === 'installing'
                                ? 'Installing'
                                : server.status === 'restoring_backup'
                                ? 'Restoring Backup'
                                : 'Unavailable'}
                        </span>
                    ) : (
                        <Spinner size={'small'} />
                    )
                ) : (
                    <React.Fragment>
                        {stat(faMicrochip, 'CPU', meters.cpu, alarms.cpu, cpuLimit)}
                        {stat(faMemory, 'RAM', meters.memory, alarms.memory, memoryLimit)}
                        {stat(faHdd, 'Disk', meters.disk, alarms.disk, diskLimit)}
                    </React.Fragment>
                )}
            </div>
            <div className={'status-bar'} />
        </StatusIndicatorBox>
    );
};
