import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import useEventListener from '@/plugins/useEventListener';
import SearchModal from '@/components/dashboard/search/SearchModal';

export default () => {
    const [visible, setVisible] = useState(false);

    useEventListener('keydown', (e: KeyboardEvent) => {
        if (e.metaKey || e.ctrlKey || ['input', 'textarea'].indexOf(((e.target as HTMLElement).tagName || 'input').toLowerCase()) < 0) {
            if (!visible && (e.metaKey || e.ctrlKey) && ['/', 'k'].includes(e.key.toLowerCase())) {
                e.preventDefault();
                setVisible(true);
            }
        }
    });

    return (
        <>
            {visible && <SearchModal appear visible={visible} onDismissed={() => setVisible(false)} />}
            <button type={'button'} className={'vz-search'} onClick={() => setVisible(true)} aria-label={'Search servers'}>
                <FontAwesomeIcon icon={faSearch} />
                <span>Search servers</span>
                <kbd>Ctrl K</kbd>
            </button>
        </>
    );
};
