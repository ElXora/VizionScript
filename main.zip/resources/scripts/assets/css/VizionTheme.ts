import { createGlobalStyle } from 'styled-components/macro';
import '@/plugins/appearance';

/**
 * Vizion design system.
 * - gray / primary ramps in tailwind.config.js point at the --vz-g* / --vz-p* variables defined here,
 *   so every existing component follows the active mode and accent automatically.
 * - plugins/appearance.ts writes the user's choices (mode, accent, background ...) onto <html>.
 */
export default createGlobalStyle`
/* ============================================================ tokens: dark (default) */
:root, html[data-vz-mode='dark'] {
    --vz-g50: #F5F7FA; --vz-g100: #E6E9EF; --vz-g200: #C9CFD9; --vz-g300: #A8B0BD; --vz-g400: #7D8797;
    --vz-g500: #596273; --vz-g600: #1A2230; --vz-g700: #10151D; --vz-g800: #0A0E14; --vz-g900: #07090D;
    --vz-bg-rgb: 7, 9, 13; --vz-bg2-rgb: 10, 14, 20; --vz-surface-rgb: 16, 21, 29; --vz-elev-rgb: 20, 26, 35; --vz-elev2-rgb: 24, 31, 42;
    --vz-ov: 255, 255, 255; --vz-console: #05070A;
    --vz-tx: #F5F7FA; --vz-tx2: #A8B0BD; --vz-tx3: #7D8797;
    --vz-line: 0.07; --vz-line-strong: 0.13;
    --vz-sh1: 0 1px 2px rgba(0, 0, 0, 0.35); --vz-sh2: 0 8px 24px -10px rgba(0, 0, 0, 0.6); --vz-sh3: 0 24px 64px -16px rgba(0, 0, 0, 0.75);
    --vz-scroll: #232c3a; --vz-scroll-h: #313c4e; --vz-scrim: 4, 6, 10;
}
html[data-vz-mode='oled'] {
    --vz-g800: #000000; --vz-g900: #000000; --vz-g700: #090B0F; --vz-g600: #14181F;
    --vz-bg-rgb: 0, 0, 0; --vz-bg2-rgb: 0, 0, 0; --vz-surface-rgb: 9, 11, 15; --vz-elev-rgb: 14, 17, 22; --vz-elev2-rgb: 19, 23, 30;
    --vz-line: 0.08; --vz-line-strong: 0.15; --vz-scroll: #1b222c; --vz-scrim: 0, 0, 0;
}
html[data-vz-mode='light'] {
    --vz-g50: #0F1722; --vz-g100: #1D2939; --vz-g200: #344054; --vz-g300: #475467; --vz-g400: #667085;
    --vz-g500: #98A2B3; --vz-g600: #E9EDF3; --vz-g700: #FFFFFF; --vz-g800: #F1F3F7; --vz-g900: #E4E8EE;
    --vz-bg-rgb: 241, 243, 247; --vz-bg2-rgb: 244, 246, 249; --vz-surface-rgb: 255, 255, 255; --vz-elev-rgb: 250, 251, 253; --vz-elev2-rgb: 255, 255, 255;
    --vz-ov: 15, 23, 42; --vz-console: #0B0F16;
    --vz-tx: #0F1722; --vz-tx2: #475467; --vz-tx3: #667085;
    --vz-line: 0.09; --vz-line-strong: 0.16;
    --vz-sh1: 0 1px 2px rgba(15, 23, 42, 0.06); --vz-sh2: 0 8px 24px -12px rgba(15, 23, 42, 0.22); --vz-sh3: 0 24px 64px -20px rgba(15, 23, 42, 0.35);
    --vz-scroll: #cdd3dd; --vz-scroll-h: #b4bcc9; --vz-scrim: 15, 23, 42;
}
:root {
    --vz-p50: #EEF4FF; --vz-p100: #DCE8FF; --vz-p200: #BCD3FF; --vz-p300: #93B7FF; --vz-p400: #6A9CFF;
    --vz-p500: #4F8CFF; --vz-p600: #3A74E8; --vz-p700: #2D5BC0; --vz-p800: #264A99; --vz-p900: #223F78;
    --vz-accent: #4F8CFF; --vz-accent-h: #6A9CFF; --vz-acc-rgb: 79, 140, 255;
    --vz-radius: 10px;
    --vz-bg: rgb(var(--vz-bg-rgb)); --vz-bg2: rgb(var(--vz-bg2-rgb)); --vz-surface: rgb(var(--vz-surface-rgb));
    --vz-elev: rgb(var(--vz-elev-rgb)); --vz-elev2: rgb(var(--vz-elev2-rgb));
    --vz-bd: rgba(var(--vz-ov), var(--vz-line)); --vz-bd-strong: rgba(var(--vz-ov), var(--vz-line-strong));
    --vz-accent-bg: rgba(var(--vz-acc-rgb), 0.12);
    --vz-ok: #3FB27F; --vz-warn: #E0A33A; --vz-err: #E5605A;
    --vz-r-sm: calc(var(--vz-radius) * 0.8); --vz-r-md: var(--vz-radius); --vz-r-lg: calc(var(--vz-radius) * 1.4); --vz-r-xl: calc(var(--vz-radius) * 1.8);
    --vz-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --vz-fast: 140ms; --vz-base: 200ms; --vz-slow: 300ms;
    --vz-sw: 248px; --vz-top: 56px; --vz-row: 38px;
    --vz-mono: 'JetBrains Mono', 'SF Mono', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    --vz-font: 'Inter', 'Roboto', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif;
}
html[data-vz-density='compact'] { --vz-row: 32px; --vz-top: 50px; }
html[data-vz-collapsed='1'] { --vz-sw: 68px; }
@media (max-width: 1023px) { :root, html[data-vz-collapsed='1'] { --vz-sw: 0px; } }
html[data-vz-font='system'] { --vz-font: ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif; }
html[data-vz-font='plex'] { --vz-font: 'IBM Plex Sans', 'Roboto', system-ui, sans-serif; }
html[data-vz-font='default'] body, html[data-vz-font='system'] body, html[data-vz-font='plex'] body { font-family: var(--vz-font); }

html { color-scheme: dark; background: var(--vz-bg); }
html[data-vz-mode='light'] { color-scheme: light; }
body { background: transparent !important; color: var(--vz-tx); -webkit-font-smoothing: antialiased; text-rendering: optimizeLegibility; font-variant-numeric: tabular-nums; }
::selection { background: rgba(var(--vz-acc-rgb), 0.4); color: #fff; }
* { scrollbar-width: thin; scrollbar-color: var(--vz-scroll) transparent; }
::-webkit-scrollbar { width: 8px; height: 8px; background: none; }
::-webkit-scrollbar-thumb { background: var(--vz-scroll); border-radius: 8px; }
::-webkit-scrollbar-thumb:hover { background: var(--vz-scroll-h); }
:focus-visible { outline: 2px solid rgba(var(--vz-acc-rgb), 0.7); outline-offset: 2px; }
h1, h2, h3, h4 { letter-spacing: -0.012em; color: var(--vz-tx); }
code, pre, kbd, samp { font-family: var(--vz-mono); }
a { transition: color var(--vz-fast) ease, opacity var(--vz-fast) ease; }

/* ============================================================ background layers (Appearance → Background) */
body::before, body::after { content: ''; position: fixed; inset: 0; z-index: -1; pointer-events: none; }
html[data-vz-bg='dots'] body::before {
    background-image: radial-gradient(rgba(var(--vz-ov), 0.1) 1px, transparent 1px);
    background-size: 22px 22px;
    -webkit-mask-image: radial-gradient(ellipse 80% 60% at 50% 0%, #000 20%, transparent 78%);
    mask-image: radial-gradient(ellipse 80% 60% at 50% 0%, #000 20%, transparent 78%);
}
html[data-vz-bg='dots'] body::after { background: radial-gradient(1200px 380px at 50% -10%, rgba(var(--vz-acc-rgb), 0.05), transparent 70%); }
html[data-vz-bg='glow'] body::before {
    background: radial-gradient(900px 520px at 12% -8%, rgba(var(--vz-acc-rgb), 0.12), transparent 70%), radial-gradient(700px 480px at 100% 0%, rgba(var(--vz-acc-rgb), 0.05), transparent 70%);
}
html[data-vz-bg='color'] body::before { background: var(--vz-bg-color); }
html[data-vz-bg='gradient'] body::before { background: var(--vz-bg-grad); }
html[data-vz-bg='image'] body::before {
    background: var(--vz-bg-image) center / cover no-repeat; filter: blur(var(--vz-bg-blur)); transform: scale(1.06);
}
html[data-vz-bg='image'] body::after { background: rgba(var(--vz-scrim), var(--vz-bg-dim)); }
/* with a custom picture the surfaces turn slightly translucent so it shows through */
html[data-vz-bg='image'], html[data-vz-bg='gradient'], html[data-vz-bg='color'] { --vz-surface-alpha: 0.82; }
html[data-vz-bg='image'][data-vz-mode='dark'], html[data-vz-bg='image'][data-vz-mode='oled'] { --vz-g700: rgba(14, 18, 25, 0.82); --vz-g800: rgba(8, 11, 16, 0.72); --vz-g900: rgba(6, 8, 12, 0.8); --vz-g600: rgba(26, 34, 48, 0.8); }
html[data-vz-bg='image'][data-vz-mode='light'] { --vz-g700: rgba(255, 255, 255, 0.84); --vz-g800: rgba(244, 246, 250, 0.74); --vz-g900: rgba(236, 240, 246, 0.8); --vz-g600: rgba(233, 237, 243, 0.82); }
html[data-vz-bg='image'] .vz-side, html[data-vz-bg='image'] .vz-topbar { background: rgba(var(--vz-bg2-rgb), 0.7) !important; }

/* ============================================================ shell */
.vz-shell #app { padding-left: var(--vz-sw); transition: padding-left var(--vz-slow) var(--vz-ease); }
.vz-side {
    position: fixed; inset: 0 auto 0 0; width: var(--vz-sw); z-index: 40; display: flex; flex-direction: column;
    background: rgba(var(--vz-bg2-rgb), 0.88); -webkit-backdrop-filter: blur(18px); backdrop-filter: blur(18px);
    border-right: 1px solid var(--vz-bd);
    transition: width var(--vz-slow) var(--vz-ease), transform var(--vz-slow) var(--vz-ease);
    overflow: hidden; overflow: clip; contain: layout paint;
}
.vz-side-head { display: flex; align-items: center; justify-content: space-between; height: var(--vz-top); padding: 0 16px; border-bottom: 1px solid var(--vz-bd); flex: none; }
.vz-brand { display: flex; align-items: center; gap: 10px; min-width: 0; color: var(--vz-tx); text-decoration: none; font-weight: 600; font-size: 15px; letter-spacing: -0.01em; }
.vz-brand img { width: 24px; height: 24px; flex: none; }
html[data-vz-mode='dark'] .vz-brand img, html[data-vz-mode='oled'] .vz-brand img { filter: brightness(0) invert(1); opacity: 0.92; }
html[data-vz-mode='light'] .vz-brand img { filter: brightness(0); opacity: 0.85; }
.vz-brand span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vz-nav { position: relative; flex: 1; min-width: 0; padding: 14px 10px; display: flex; flex-direction: column; gap: 2px; overflow-y: auto; overflow-x: hidden; }
.vz-nav-label { padding: 0 10px 8px; font-family: var(--vz-mono); font-size: 10.5px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.14em; color: var(--vz-tx3) !important; white-space: nowrap; }
.vz-item {
    position: relative; display: flex; align-items: center; gap: 12px; height: var(--vz-row); padding: 0 12px; flex: none;
    border-radius: var(--vz-r-md); color: var(--vz-tx2); font-size: 14px; font-weight: 500; text-decoration: none; white-space: nowrap;
    border: 1px solid transparent; transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease, border-color var(--vz-fast) ease;
}
.vz-item svg { width: 16px; height: 16px; flex: none; color: var(--vz-tx3); transition: color var(--vz-fast) ease, transform var(--vz-base) var(--vz-ease); }
.vz-item:hover { background: rgba(var(--vz-ov), 0.05); color: var(--vz-tx); }
.vz-item:hover svg { color: var(--vz-tx2); transform: translateX(1px); }
.vz-item.active { background: var(--vz-accent-bg); border-color: rgba(var(--vz-acc-rgb), 0.22); color: var(--vz-tx); }
.vz-item.active svg { color: var(--vz-accent-h); }
.vz-ind { position: absolute; left: 0; top: 0; width: 3px; border-radius: 0 3px 3px 0; background: var(--vz-accent); pointer-events: none; transition: transform var(--vz-slow) var(--vz-ease), height var(--vz-slow) var(--vz-ease), opacity var(--vz-base) ease; }
.vz-side-foot { flex: none; padding: 10px; border-top: 1px solid var(--vz-bd); display: flex; flex-direction: column; gap: 6px; }
.vz-user { display: flex; align-items: center; gap: 10px; padding: 8px; border-radius: var(--vz-r-md); background: rgba(var(--vz-ov), 0.035); border: 1px solid var(--vz-bd); min-width: 0; }
.vz-avatar { width: 32px; height: 32px; flex: none; border-radius: calc(var(--vz-radius) * 0.8); overflow: hidden; display: block; }
.vz-avatar > * { width: 100%; height: 100%; }
.vz-user-meta { min-width: 0; flex: 1; }
.vz-user-meta p { font-size: 13px; font-weight: 600; line-height: 1.2; color: var(--vz-tx); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vz-user-meta small { font-size: 11px; color: var(--vz-tx3); }
.vz-icon-btn { width: 32px; height: 32px; flex: none; display: inline-flex; align-items: center; justify-content: center; border-radius: var(--vz-r-sm); color: var(--vz-tx2); background: transparent; border: 1px solid transparent; cursor: pointer; transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease, transform var(--vz-fast) ease; }
.vz-icon-btn:hover { background: rgba(var(--vz-ov), 0.08); color: var(--vz-tx); }
.vz-icon-btn:active { transform: scale(0.94); }
.vz-foot-btn { display: flex; align-items: center; gap: 12px; height: 34px; padding: 0 12px; border-radius: var(--vz-r-md); color: var(--vz-tx3); font-size: 13px; background: transparent; border: 0; cursor: pointer; text-align: left; transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease; }
.vz-foot-btn:hover { background: rgba(var(--vz-ov), 0.05); color: var(--vz-tx); }
.vz-foot-btn svg { width: 14px; flex: none; transition: transform var(--vz-slow) var(--vz-ease); }
html[data-vz-collapsed='1'] .vz-collapse svg { transform: rotate(180deg); }
.vz-scrim { display: none; }
.vz-only-mobile { display: none !important; }
@media (min-width: 1024px) {
    html[data-vz-collapsed='1'] .vz-side-head { justify-content: center; padding: 0; }
    html[data-vz-collapsed='1'] .vz-brand span, html[data-vz-collapsed='1'] .vz-item span, html[data-vz-collapsed='1'] .vz-nav-label,
    html[data-vz-collapsed='1'] .vz-user-meta, html[data-vz-collapsed='1'] .vz-foot-btn span { display: none; }
    html[data-vz-collapsed='1'] .vz-item, html[data-vz-collapsed='1'] .vz-foot-btn { justify-content: center; padding: 0; }
    html[data-vz-collapsed='1'] .vz-user { flex-direction: column; padding: 8px 4px; }
}

/* ============================================================ top bar + tabs */
.vz-topbar {
    position: sticky; top: 0; z-index: 30; height: var(--vz-top); display: flex; align-items: center; gap: 12px; padding: 0 24px;
    background: rgba(var(--vz-bg2-rgb), 0.74); -webkit-backdrop-filter: blur(16px) saturate(140%); backdrop-filter: blur(16px) saturate(140%); border-bottom: 1px solid var(--vz-bd);
}
.vz-crumbs { display: flex; align-items: center; gap: 8px; min-width: 0; flex: 1; font-size: 13px; list-style: none; margin: 0; padding: 0; }
.vz-crumbs li { display: flex; align-items: center; gap: 8px; color: var(--vz-tx3); white-space: nowrap; }
.vz-crumbs li + li::before { content: '/'; color: var(--vz-bd-strong); }
.vz-crumbs li:last-child { color: var(--vz-tx); font-weight: 500; }
.vz-crumbs a { color: var(--vz-tx3); text-decoration: none; } .vz-crumbs a:hover { color: var(--vz-tx); }
.vz-topbar-actions { display: flex; align-items: center; gap: 8px; }
.vz-search { display: inline-flex; align-items: center; gap: 10px; height: 34px; min-width: 240px; padding: 0 10px 0 12px; background: rgba(var(--vz-ov), 0.04); border: 1px solid var(--vz-bd); border-radius: var(--vz-r-md); color: var(--vz-tx3); font-size: 13px; cursor: pointer; transition: border-color var(--vz-fast) ease, background-color var(--vz-fast) ease, color var(--vz-fast) ease; }
.vz-search:hover { border-color: var(--vz-bd-strong); background: rgba(var(--vz-ov), 0.07); color: var(--vz-tx2); }
.vz-search span { flex: 1; text-align: left; }
.vz-search kbd { font-size: 11px; padding: 2px 6px; border-radius: 6px; border: 1px solid var(--vz-bd-strong); color: var(--vz-tx3); background: rgba(var(--vz-ov), 0.05); }
.vz-topbar + div:has(> div > a) { position: sticky; top: var(--vz-top); z-index: 20; background: rgba(var(--vz-bg2-rgb), 0.74) !important; box-shadow: none !important; -webkit-backdrop-filter: blur(14px); backdrop-filter: blur(14px); border-bottom: 1px solid var(--vz-bd); }
.vz-topbar + div:has(> div > a) > div { max-width: 1240px; padding: 0 12px; }
.vz-topbar + div:has(> div > a) > div > a, .vz-topbar + div:has(> div > a) > div > div { position: relative; margin: 0 !important; padding: 13px 14px !important; color: var(--vz-tx3) !important; font-weight: 500; box-shadow: none !important; border: 0 !important; transition: color var(--vz-fast) ease !important; }
.vz-topbar + div:has(> div > a) > div > a:hover { color: var(--vz-tx) !important; }
.vz-topbar + div:has(> div > a) > div > a::after { content: ''; position: absolute; left: 14px; right: 14px; bottom: -1px; height: 2px; border-radius: 2px; background: var(--vz-accent); transform: scaleX(0); transition: transform var(--vz-base) var(--vz-ease); }
.vz-topbar + div:has(> div > a) > div > a.active { color: var(--vz-tx) !important; }
.vz-topbar + div:has(> div > a) > div > a.active::after { transform: scaleX(1); }

/* ============================================================ page */
[class*='ContentContainer-sc'], [class^='ContentContainer'] { box-sizing: border-box; max-width: 1240px !important; padding-left: clamp(16px, 2.4vw, 32px); padding-right: clamp(16px, 2.4vw, 32px); margin-left: auto !important; margin-right: auto !important; }
.vz-page-head { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; margin-bottom: 20px; }
.vz-page-head h1 { font-size: 26px; font-weight: 600; line-height: 1.15; }
.vz-page-head p { margin-top: 4px; font-size: 12.5px; color: var(--vz-tx3); font-family: var(--vz-mono); }
.fade-enter { opacity: 0; transform: translateY(8px); }
.fade-enter-active { opacity: 1; transform: none; transition: opacity 220ms ease, transform 260ms var(--vz-ease); }
.fade-exit { opacity: 1; }
.fade-exit-active { opacity: 0; transition: opacity 120ms ease; }

/* ============================================================ surfaces */
[class*='GreyRowBox'], a[class*='ServerRow__StatusIndicatorBox'] {
    background: var(--vz-surface) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-lg) !important; box-shadow: var(--vz-sh1);
    transition: transform var(--vz-base) var(--vz-ease), border-color var(--vz-fast) ease, background-color var(--vz-fast) ease, box-shadow var(--vz-base) ease !important;
}
a[class*='ServerRow__StatusIndicatorBox'] { padding: 16px 20px !important; }
a[class*='ServerRow__StatusIndicatorBox']:hover, [class*='GreyRowBox']:hover { background: var(--vz-elev) !important; border-color: var(--vz-bd-strong); transform: translateY(-1px) scale(1.002); box-shadow: var(--vz-sh2); }
[class^='ServerRow__Icon-sc'], [class*=' ServerRow__Icon-sc'], .icon { background: rgba(var(--vz-ov), 0.045) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-md) !important; }
[class*='ServerRow__StatusIndicatorBox'] .status-bar { width: 8px !important; height: 8px !important; top: 50%; right: 18px !important; margin: 0 !important; transform: translateY(-50%); border-radius: 50% !important; opacity: 1 !important; box-shadow: 0 0 0 3px rgba(var(--vz-ov), 0.06); }
.vz-meter { height: 3px; margin: 7px auto 0; width: 76px; border-radius: 3px; background: rgba(var(--vz-ov), 0.1); overflow: hidden; }
.vz-meter i { display: block; height: 100%; width: 0; border-radius: inherit; background: var(--vz-accent); transition: width var(--vz-slow) var(--vz-ease), background-color var(--vz-base) ease; }
.vz-meter i[data-alarm='1'] { background: var(--vz-err); }
[class*='TitledGreyBox___StyledDiv']:not([class*='StyledDiv2']):not([class*='StyledDiv3']) { background: var(--vz-surface) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-lg) !important; box-shadow: var(--vz-sh1); overflow: hidden; }
[class*='TitledGreyBox___StyledDiv2'] { background: var(--vz-elev) !important; border-bottom: 1px solid var(--vz-bd); padding: 12px 16px !important; font-size: 13px; font-weight: 500; }
[class*='ContentBox___Styled'] > h2 { font-size: 13px; font-weight: 600; letter-spacing: 0.01em; color: var(--vz-tx2) !important; padding: 0 2px !important; margin-bottom: 10px !important; }
[class*='ContentBox___Styled'] > div:last-child { background: var(--vz-surface) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-lg) !important; box-shadow: var(--vz-sh1) !important; padding: 18px !important; }
html[data-vz-density='compact'] [class*='ContentBox___Styled'] > div:last-child { padding: 14px !important; }
.vz-skeleton-list { display: flex; flex-direction: column; gap: 8px; }
.vz-skel { height: 76px; border-radius: var(--vz-r-lg); border: 1px solid var(--vz-bd); background: linear-gradient(100deg, var(--vz-surface) 30%, var(--vz-elev) 50%, var(--vz-surface) 70%); background-size: 250% 100%; animation: vzShimmer 2.2s ease-in-out infinite; }

.vz-dialog-scrim { background: rgba(var(--vz-scrim), 0.55); -webkit-backdrop-filter: blur(4px); backdrop-filter: blur(4px); }
/* ============================================================ controls */
[class*='Button__ButtonStyle'] { border-radius: var(--vz-r-md) !important; font-weight: 500 !important; letter-spacing: 0 !important; border-width: 1px !important; transition: transform var(--vz-fast) ease, filter var(--vz-fast) ease, box-shadow var(--vz-base) ease, background-color var(--vz-fast) ease, border-color var(--vz-fast) ease !important; }
[class*='Button__ButtonStyle']:hover:not(:disabled) { filter: brightness(1.08); }
[class*='Button__ButtonStyle']:active:not(:disabled), button:active:not(:disabled) { transform: scale(0.97); }
[class*='Button__ButtonStyle']:disabled { opacity: 0.5; cursor: not-allowed; }
input:not([type='checkbox']):not([type='radio']):not([type='file']):not([type='range']):not([type='color']), textarea, select {
    background-color: rgba(var(--vz-ov), 0.04) !important; border: 1px solid var(--vz-bd-strong) !important; border-radius: var(--vz-r-md) !important; color: var(--vz-tx) !important;
    transition: border-color var(--vz-fast) ease, box-shadow var(--vz-base) ease, background-color var(--vz-fast) ease !important;
}
input:not([type='checkbox']):not([type='radio']):not([type='file']):not([type='range']):not([type='color']):hover, textarea:hover, select:hover { border-color: rgba(var(--vz-ov), 0.28) !important; }
input:not([type='checkbox']):not([type='radio']):not([type='file']):not([type='range']):not([type='color']):focus, textarea:focus, select:focus { border-color: var(--vz-accent) !important; background-color: rgba(var(--vz-acc-rgb), 0.06) !important; box-shadow: 0 0 0 3px rgba(var(--vz-acc-rgb), 0.2) !important; }
input::placeholder, textarea::placeholder { color: var(--vz-tx3) !important; opacity: 0.8; }
input:disabled, textarea:disabled, select:disabled { opacity: 0.55; cursor: not-allowed; }
input[type='checkbox'], input[type='radio'], input[type='range'] { accent-color: var(--vz-accent); }
label, [class*='Label-sc'] { color: var(--vz-tx2); font-weight: 500; }
[class*='InputError'] { color: var(--vz-err) !important; }
[class*='Switch__ToggleContainer'], [class*='Switch___StyledToggleContainer'] { transition: background-color var(--vz-base) ease !important; }
[class*='Switch__ToggleContainer'] > *, [class*='Switch___StyledToggleContainer'] > * { transition: transform var(--vz-base) var(--vz-ease), background-color var(--vz-base) ease !important; }
[class*='ProgressBar'] { border-radius: 99px !important; height: 4px !important; }
[class*='ProgressBar__BarFill'] { border-radius: 99px !important; transition: width var(--vz-slow) var(--vz-ease) !important; }
[class*='SpinnerOverlay___StyledDiv'] { -webkit-backdrop-filter: blur(4px); backdrop-filter: blur(4px); }

/* ============================================================ overlays */
[class*='Modal__ModalMask'] { background: rgba(var(--vz-scrim), 0.62) !important; -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); }
[class*='Modal__ModalContainer'] { background: var(--vz-elev) !important; border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-xl) !important; box-shadow: var(--vz-sh3) !important; animation: vzModal 200ms var(--vz-ease) backwards; }
@media (max-width: 640px) { [class*='Modal__ModalContainer'] { width: calc(100vw - 24px) !important; max-height: calc(100vh - 24px); overflow-y: auto; } }
[class*='DropdownMenu___StyledDiv'] { background: var(--vz-elev2) !important; border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-lg) !important; box-shadow: var(--vz-sh2) !important; animation: vzPop 140ms var(--vz-ease) backwards; transform-origin: top right; }
[class*='DropdownMenu__DropdownButtonRow'], [class*='FileDropdownMenu__StyledRow'] { border-radius: var(--vz-r-sm) !important; transition: background-color var(--vz-fast) ease !important; }
[role='tooltip'] { border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-sm) !important; background: var(--vz-elev2) !important; color: var(--vz-tx) !important; box-shadow: var(--vz-sh2); font-size: 12px; }
[class*='MessageBox__Container'] { border-radius: var(--vz-r-md) !important; border: 1px solid var(--vz-bd-strong) !important; background: var(--vz-elev) !important; box-shadow: var(--vz-sh2); animation: vzSlide 260ms var(--vz-ease) backwards; }

/* ============================================================ console / files / editor / charts */
.xterm { padding: 12px 14px; font-family: var(--vz-mono) !important; }
div:has(> .xterm) { background: var(--vz-console) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-lg); overflow: hidden; }
[class*='FileObjectRow___StyledDiv'] { border-radius: var(--vz-r-sm); transition: background-color var(--vz-fast) ease !important; }
[class*='FileObjectRow___StyledDiv']:hover { background: rgba(var(--vz-ov), 0.05) !important; }
.cm-editor, [class*='CodemirrorEditor'] { border-radius: var(--vz-r-lg); font-family: var(--vz-mono) !important; }
canvas { border-radius: var(--vz-r-sm); }
table { border-collapse: collapse; }
th { color: var(--vz-tx3); font-weight: 500; font-size: 11px; text-transform: uppercase; letter-spacing: 0.06em; }
tbody tr { border-top: 1px solid var(--vz-bd); transition: background-color var(--vz-fast) ease; } tbody tr:hover { background: rgba(var(--vz-ov), 0.04); }

/* ============================================================ auth */
form > div:has(> div > img[src*='pterodactyl.svg']) { position: relative; display: block !important; max-width: 420px; margin: 0 auto !important; padding: 32px !important; background: rgba(var(--vz-surface-rgb), 0.82) !important; border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-xl) !important; box-shadow: var(--vz-sh3) !important; -webkit-backdrop-filter: blur(18px); backdrop-filter: blur(18px); animation: vzModal 420ms var(--vz-ease) backwards; }
form > div:has(> div > img[src*='pterodactyl.svg'])::before, form > div:has(> div > img[src*='pterodactyl.svg'])::after { content: ''; position: absolute; width: 10px; height: 10px; border: 1px solid var(--vz-accent); opacity: 0.7; pointer-events: none; }
form > div:has(> div > img[src*='pterodactyl.svg'])::before { top: -1px; left: -1px; border-right: 0; border-bottom: 0; border-top-left-radius: var(--vz-r-xl); }
form > div:has(> div > img[src*='pterodactyl.svg'])::after { right: -1px; bottom: -1px; border-left: 0; border-top: 0; border-bottom-right-radius: var(--vz-r-xl); }
form > div:has(> div > img[src*='pterodactyl.svg']) > div:first-child { margin: 0 0 24px !important; display: flex; justify-content: center; }
form img[src*='pterodactyl.svg'] { width: 56px !important; height: 56px; margin: 0 !important; }
html[data-vz-mode='dark'] form img[src*='pterodactyl.svg'], html[data-vz-mode='oled'] form img[src*='pterodactyl.svg'] { filter: brightness(0) invert(1); }
html[data-vz-mode='light'] form img[src*='pterodactyl.svg'] { filter: brightness(0); }
form > div:has(> div > img[src*='pterodactyl.svg']) label { color: var(--vz-tx2) !important; font-family: var(--vz-mono); font-size: 11px; letter-spacing: 0.08em; }
form > div:has(> div > img[src*='pterodactyl.svg']) a { color: var(--vz-tx3) !important; text-decoration: none; }
form > div:has(> div > img[src*='pterodactyl.svg']) a:hover { color: var(--vz-accent-h) !important; }
form > div:has(> div > img[src*='pterodactyl.svg']) > div:last-child > * { animation: vzRise 480ms var(--vz-ease) backwards; }
form > div:has(> div > img[src*='pterodactyl.svg']) > div:last-child > *:nth-child(2) { animation-delay: 60ms; }
form > div:has(> div > img[src*='pterodactyl.svg']) > div:last-child > *:nth-child(3) { animation-delay: 120ms; }
form > div:has(> div > img[src*='pterodactyl.svg']) > div:last-child > *:nth-child(4) { animation-delay: 180ms; }

/* ============================================================ appearance editor */
.vz-ae { position: fixed; top: 0; right: 0; bottom: 0; width: 372px; max-width: 100vw; z-index: 80; display: flex; flex-direction: column; background: rgba(var(--vz-elev-rgb), 0.96); -webkit-backdrop-filter: blur(20px); backdrop-filter: blur(20px); border-left: 1px solid var(--vz-bd-strong); box-shadow: var(--vz-sh3); transform: translateX(104%); transition: transform var(--vz-slow) var(--vz-ease); }
.vz-ae[data-open='1'] { transform: none; }
.vz-ae-head { display: flex; align-items: center; justify-content: space-between; height: var(--vz-top); padding: 0 16px 0 20px; border-bottom: 1px solid var(--vz-bd); flex: none; }
.vz-ae-head h3 { font-size: 14px; font-weight: 600; }
.vz-ae-body { flex: 1; overflow-y: auto; padding: 6px 20px 20px; }
.vz-ae-sec { padding: 16px 0; border-bottom: 1px solid var(--vz-bd); }
.vz-ae-sec:last-child { border-bottom: 0; }
.vz-ae-lab { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; font-family: var(--vz-mono); font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.14em; color: var(--vz-tx3); }
.vz-ae-lab b { font-weight: 500; color: var(--vz-tx2); letter-spacing: 0.04em; text-transform: none; }
.vz-seg { display: grid; grid-auto-flow: column; grid-auto-columns: 1fr; gap: 4px; padding: 3px; border-radius: var(--vz-r-md); background: rgba(var(--vz-ov), 0.05); border: 1px solid var(--vz-bd); }
.vz-seg button { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px; min-height: 34px; padding: 6px 4px; border-radius: calc(var(--vz-radius) * 0.7); border: 0; background: transparent; color: var(--vz-tx2); font-size: 12px; cursor: pointer; transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease; }
.vz-seg button:hover { color: var(--vz-tx); }
.vz-seg button[aria-pressed='true'] { background: var(--vz-elev2); color: var(--vz-tx); box-shadow: var(--vz-sh1), inset 0 0 0 1px var(--vz-bd-strong); }
.vz-swatches { display: flex; flex-wrap: wrap; gap: 8px; }
.vz-swatch { width: 26px; height: 26px; border-radius: 50%; border: 2px solid transparent; padding: 0; cursor: pointer; box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.25); transition: transform var(--vz-fast) ease; }
.vz-swatch:hover { transform: scale(1.1); }
.vz-swatch[aria-pressed='true'] { border-color: var(--vz-bg); outline: 2px solid var(--vz-tx); }
.vz-row { display: flex; align-items: center; gap: 10px; margin-top: 10px; }
.vz-row > * { min-width: 0; }
.vz-row input[type='range'] { flex: 1; }
.vz-row input[type='color'] { width: 36px; height: 32px; padding: 2px; border-radius: var(--vz-r-sm); border: 1px solid var(--vz-bd-strong); background: transparent; cursor: pointer; flex: none; }
.vz-row input[type='text'], .vz-ae textarea { flex: 1; height: 32px; padding: 0 10px; font-family: var(--vz-mono); font-size: 12px; }
.vz-ae textarea { width: 100%; height: 120px; padding: 10px; resize: vertical; }
.vz-mini { height: 32px; padding: 0 12px; border-radius: var(--vz-r-sm); border: 1px solid var(--vz-bd-strong); background: rgba(var(--vz-ov), 0.05); color: var(--vz-tx); font-size: 12px; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: background-color var(--vz-fast) ease; }
.vz-mini:hover { background: rgba(var(--vz-ov), 0.1); }
.vz-mini.danger { color: var(--vz-err); }
.vz-ae-foot { display: flex; gap: 8px; padding: 12px 20px; border-top: 1px solid var(--vz-bd); flex: none; }
.vz-ae-note { margin-top: 8px; font-size: 11.5px; color: var(--vz-tx3); line-height: 1.45; }
.vz-ae-note.err { color: var(--vz-err); }

/* ============================================================ motion */
@keyframes vzRise { from { opacity: 0; transform: translateY(10px); } }
@keyframes vzModal { from { opacity: 0; transform: translateY(8px) scale(0.97); } }
@keyframes vzPop { from { opacity: 0; transform: scale(0.96); } }
@keyframes vzSlide { from { opacity: 0; transform: translateY(-8px); } }
@keyframes vzShimmer { from { background-position: 150% 0; } to { background-position: -50% 0; } }
html[data-vz-density='compact'] a[class*='ServerRow__StatusIndicatorBox'] { padding: 10px 16px !important; }

/* ============================================================ responsive */
@media (max-width: 1023px) {
    .vz-only-mobile { display: inline-flex !important; }
    .vz-only-desktop { display: none !important; }
    .vz-side { width: 272px; transform: translateX(-102%); box-shadow: none; z-index: 60; }
    .vz-side[data-open='1'] { transform: none; box-shadow: var(--vz-sh3); }
    .vz-scrim { display: block; position: fixed; inset: 0; z-index: 55; background: rgba(var(--vz-scrim), 0.6); -webkit-backdrop-filter: blur(3px); backdrop-filter: blur(3px); opacity: 0; pointer-events: none; transition: opacity var(--vz-base) ease; }
    .vz-scrim[data-open='1'] { opacity: 1; pointer-events: auto; }
    .vz-topbar { padding: 0 14px; }
    .vz-search { min-width: 0; width: 34px; padding: 0; justify-content: center; }
    .vz-search span, .vz-search kbd { display: none; }
}
@media (max-width: 640px) {
    .vz-page-head { flex-direction: column; align-items: flex-start; }
    .vz-page-head h1 { font-size: 22px; }
    a[class*='ServerRow__StatusIndicatorBox'] { padding: 14px 40px 14px 14px !important; }
    .vz-ae { width: 100vw; }
}
@media (prefers-reduced-motion: reduce) { *, *::before, *::after { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; scroll-behavior: auto !important; } }
html[data-vz-motion='reduced'] *, html[data-vz-motion='reduced'] *::before, html[data-vz-motion='reduced'] *::after { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; scroll-behavior: auto !important; }
`;
