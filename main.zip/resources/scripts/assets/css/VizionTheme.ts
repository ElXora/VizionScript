import { createGlobalStyle } from 'styled-components/macro';
import '@/plugins/appearance';

/**
 * Vizion design system.
 * - gray / primary ramps in tailwind.config.js point at the --vz-g* / --vz-p* variables defined here,
 *   so every existing component follows the active mode and accent automatically.
 * - plugins/appearance.ts writes the user's choices (mode, accent, background ...) onto <html>.
 */
export default createGlobalStyle`
/* ============================================================ tokens: dark (default) */
:root, html[data-vz-mode='dark'] {
    --vz-g50: #F5F7FA; --vz-g100: #E6E9EF; --vz-g200: #C9CFD9; --vz-g300: #A8B0BD; --vz-g400: #7D8797;
    --vz-g500: #596273; --vz-g600: #1A2230; --vz-g700: #10151D; --vz-g800: #0A0E14; --vz-g900: #07090D;
    --vz-bg-rgb: 7, 9, 13; --vz-bg2-rgb: 10, 14, 20; --vz-surface-rgb: 16, 21, 29; --vz-elev-rgb: 20, 26, 35; --vz-elev2-rgb: 24, 31, 42;
    --vz-ov: 255, 255, 255; --vz-console: #05070A;
    --vz-tx: #F5F7FA; --vz-tx2: #A8B0BD; --vz-tx3: #7D8797;
    --vz-line: 0.07; --vz-line-strong: 0.13;
    --vz-sh1: 0 1px 2px rgba(0, 0, 0, 0.35); --vz-sh2: 0 8px 24px -10px rgba(0, 0, 0, 0.6); --vz-sh3: 0 24px 64px -16px rgba(0, 0, 0, 0.75);
    --vz-scroll: #232c3a; --vz-scroll-h: #313c4e; --vz-scrim: 4, 6, 10;
}
html[data-vz-mode='oled'] {
    --vz-g800: #000000; --vz-g900: #000000; --vz-g700: #090B0F; --vz-g600: #14181F;
    --vz-bg-rgb: 0, 0, 0; --vz-bg2-rgb: 0, 0, 0; --vz-surface-rgb: 9, 11, 15; --vz-elev-rgb: 14, 17, 22; --vz-elev2-rgb: 19, 23, 30;
    --vz-line: 0.08; --vz-line-strong: 0.15; --vz-scroll: #1b222c; --vz-scrim: 0, 0, 0;
}
html[data-vz-mode='light'] {
    --vz-g50: #0F1722; --vz-g100: #1D2939; --vz-g200: #344054; --vz-g300: #475467; --vz-g400: #667085;
    --vz-g500: #98A2B3; --vz-g600: #E9EDF3; --vz-g700: #FFFFFF; --vz-g800: #F1F3F7; --vz-g900: #E4E8EE;
    --vz-bg-rgb: 241, 243, 247; --vz-bg2-rgb: 244, 246, 249; --vz-surface-rgb: 255, 255, 255; --vz-elev-rgb: 250, 251, 253; --vz-elev2-rgb: 255, 255, 255;
    --vz-ov: 15, 23, 42; --vz-console: #0B0F16;
    --vz-tx: #0F1722; --vz-tx2: #475467; --vz-tx3: #667085;
    --vz-line: 0.09; --vz-line-strong: 0.16;
    --vz-sh1: 0 1px 2px rgba(15, 23, 42, 0.06); --vz-sh2: 0 8px 24px -12px rgba(15, 23, 42, 0.22); --vz-sh3: 0 24px 64px -20px rgba(15, 23, 42, 0.35);
    --vz-scroll: #cdd3dd; --vz-scroll-h: #b4bcc9; --vz-scrim: 15, 23, 42;
}
:root {
    --vz-p50: #EEF4FF; --vz-p100: #DCE8FF; --vz-p200: #BCD3FF; --vz-p300: #93B7FF; --vz-p400: #6A9CFF;
    --vz-p500: #4F8CFF; --vz-p600: #3A74E8; --vz-p700: #2D5BC0; --vz-p800: #264A99; --vz-p900: #223F78;
    --vz-accent: #4F8CFF; --vz-accent-h: #6A9CFF; --vz-acc-rgb: 79, 140, 255;
    --vz-radius: 10px;
    --vz-bg: rgb(var(--vz-bg-rgb)); --vz-bg2: rgb(var(--vz-bg2-rgb)); --vz-surface: rgb(var(--vz-surface-rgb));
    --vz-elev: rgb(var(--vz-elev-rgb)); --vz-elev2: rgb(var(--vz-elev2-rgb));
    --vz-bd: rgba(var(--vz-ov), var(--vz-line)); --vz-bd-strong: rgba(var(--vz-ov), var(--vz-line-strong));
    --vz-accent-bg: rgba(var(--vz-acc-rgb), 0.12);
    --vz-ok: #3FB27F; --vz-warn: #E0A33A; --vz-err: #E5605A;
    --vz-r-sm: calc(var(--vz-radius) * 0.8); --vz-r-md: var(--vz-radius); --vz-r-lg: calc(var(--vz-radius) * 1.4); --vz-r-xl: calc(var(--vz-radius) * 1.8);
    --vz-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --vz-fast: 140ms; --vz-base: 200ms; --vz-slow: 300ms;
    --vz-sw: 248px; --vz-top: 56px; --vz-row: 38px;
    --vz-mono: 'JetBrains Mono', 'SF Mono', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    --vz-font: 'Inter', 'Roboto', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif;
}
html[data-vz-density='compact'] { --vz-row: 32px; --vz-top: 50px; }
html[data-vz-collapsed='1'] { --vz-sw: 68px; }
@media (max-width: 1023px) { :root, html[data-vz-collapsed='1'] { --vz-sw: 0px; } }
html[data-vz-font='system'] { --vz-font: ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif; }
html[data-vz-font='plex'] { --vz-font: 'IBM Plex Sans', 'Roboto', system-ui, sans-serif; }
html[data-vz-font='default'] body, html[data-vz-font='system'] body, html[data-vz-font='plex'] body { font-family: var(--vz-font); }

html { color-scheme: dark; background: var(--vz-bg); }
html[data-vz-mode='light'] { color-scheme: light; }
body { background: transparent !important; color: var(--vz-tx); -webkit-font-smoothing: antialiased; text-rendering: optimizeLegibility; font-variant-numeric: tabular-nums; }
::selection { background: rgba(var(--vz-acc-rgb), 0.4); color: #fff; }
* { scrollbar-width: thin; scrollbar-color: var(--vz-scroll) transparent; }
::-webkit-scrollbar { width: 8px; height: 8px; background: none; }
::-webkit-scrollbar-thumb { background: var(--vz-scroll); border-radius: 8px; }
::-webkit-scrollbar-thumb:hover { background: var(--vz-scroll-h); }
:focus-visible { outline: 2px solid rgba(var(--vz-acc-rgb), 0.7); outline-offset: 2px; }
h1, h2, h3, h4 { letter-spacing: -0.012em; color: var(--vz-tx); }
code, pre, kbd, samp { font-family: var(--vz-mono); }
a { transition: color var(--vz-fast) ease, opacity var(--vz-fast) ease; }

/* ============================================================ background layers (Appearance → Background) */
body::before, body::after { content: ''; position: fixed; inset: 0; z-index: -1; pointer-events: none; }
html[data-vz-bg='dots'] body::before {
    background-image: radial-gradient(rgba(var(--vz-ov), 0.1) 1px, transparent 1px);
    background-size: 22px 22px;
    -webkit-mask-image: radial-gradient(ellipse 80% 60% at 50% 0%, #000 20%, transparent 78%);
    mask-image: radial-gradient(ellipse 80% 60% at 50% 0%, #000 20%, transparent 78%);
}
html[data-vz-bg='dots'] body::after { background: radial-gradient(1200px 380px at 50% -10%, rgba(var(--vz-acc-rgb), 0.05), transparent 70%); }
html[data-vz-bg='glow'] body::before {
    background: radial-gradient(900px 520px at 12% -8%, rgba(var(--vz-acc-rgb), 0.12), transparent 70%), radial-gradient(700px 480px at 100% 0%, rgba(var(--vz-acc-rgb), 0.05), transparent 70%);
}
html[data-vz-bg='color'] body::before { background: var(--vz-bg-color); }
html[data-vz-bg='gradient'] body::before { background: var(--vz-bg-grad); }
html[data-vz-bg='image'] body::before {
    background: var(--vz-bg-image) center / cover no-repeat; filter: blur(var(--vz-bg-blur)); transform: scale(1.06);
}
html[data-vz-bg='image'] body::after { background: rgba(var(--vz-scrim), var(--vz-bg-dim)); }
/* with a custom picture the surfaces turn slightly translucent so it shows through */
html[data-vz-bg='image'], html[data-vz-bg='gradient'], html[data-vz-bg='color'] { --vz-surface-alpha: 0.82; }
html[data-vz-bg='image'][data-vz-mode='dark'], html[data-vz-bg='image'][data-vz-mode='oled'] { --vz-g700: rgba(14, 18, 25, 0.82); --vz-g800: rgba(8, 11, 16, 0.72); --vz-g900: rgba(6, 8, 12, 0.8); --vz-g600: rgba(26, 34, 48, 0.8); }
html[data-vz-bg='image'][data-vz-mode='light'] { --vz-g700: rgba(255, 255, 255, 0.84); --vz-g800: rgba(244, 246, 250, 0.74); --vz-g900: rgba(236, 240, 246, 0.8); --vz-g600: rgba(233, 237, 243, 0.82); }
html[data-vz-bg='image'] .vz-side, html[data-vz-bg='image'] .vz-topbar { background: rgba(var(--vz-bg2-rgb), 0.7) !important; }

/* ============================================================ shell */
.vz-shell #app { padding-left: var(--vz-sw); transition: padding-left var(--vz-slow) var(--vz-ease); }
.vz-side {
    position: fixed; inset: 0 auto 0 0; width: var(--vz-sw); z-index: 40; display: flex; flex-direction: column;
    background: rgba(var(--vz-bg2-rgb), 0.88); -webkit-backdrop-filter: blur(18px); backdrop-filter: blur(18px);
    border-right: 1px solid var(--vz-bd);
    transition: width var(--vz-slow) var(--vz-ease), transform var(--vz-slow) var(--vz-ease);
    overflow: hidden; overflow: clip; contain: layout paint;
}
.vz-side-head { display: flex; align-items: center; justify-content: space-between; height: var(--vz-top); padding: 0 16px; border-bottom: 1px solid var(--vz-bd); flex: none; }
.vz-brand { display: flex; align-items: center; gap: 10px; min-width: 0; color: var(--vz-tx); text-decoration: none; font-weight: 600; font-size: 15px; letter-spacing: -0.01em; }
.vz-brand img { width: 24px; height: 24px; flex: none; }
html[data-vz-mode='dark'] .vz-brand img, html[data-vz-mode='oled'] .vz-brand img { filter: brightness(0) invert(1); opacity: 0.92; }
html[data-vz-mode='light'] .vz-brand img { filter: brightness(0); opacity: 0.85; }
.vz-brand span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vz-nav { position: relative; flex: 1; min-width: 0; padding: 14px 10px; display: flex; flex-direction: column; gap: 2px; overflow-y: auto; overflow-x: hidden; }
.vz-nav-label { padding: 0 10px 8px; font-family: var(--vz-mono); font-size: 10.5px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.14em; color: var(--vz-tx3) !important; white-space: nowrap; }
.vz-item {
    position: relative; display: flex; align-items: center; gap: 12px; height: var(--vz-row); padding: 0 12px; flex: none;
    border-radius: var(--vz-r-md); color: var(--vz-tx2); font-size: 14px; font-weight: 500; text-decoration: none; white-space: nowrap;
    border: 1px solid transparent; transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease, border-color var(--vz-fast) ease;
}
.vz-item svg { width: 16px; height: 16px; flex: none; color: var(--vz-tx3); transition: color var(--vz-fast) ease, transform var(--vz-base) var(--vz-ease); }
.vz-item:hover { background: rgba(var(--vz-ov), 0.05); color: var(--vz-tx); }
.vz-item:hover svg { color: var(--vz-tx2); transform: translateX(1px); }
.vz-item.active { background: var(--vz-accent-bg); border-color: rgba(var(--vz-acc-rgb), 0.22); color: var(--vz-tx); }
.vz-item.active svg { color: var(--vz-accent-h); }
.vz-ind { position: absolute; left: 0; top: 0; width: 3px; border-radius: 0 3px 3px 0; background: var(--vz-accent); pointer-events: none; transition: transform var(--vz-slow) var(--vz-ease), height var(--vz-slow) var(--vz-ease), opacity var(--vz-base) ease; }
.vz-side-foot { flex: none; padding: 10px; border-top: 1px solid var(--vz-bd); display: flex; flex-direction: column; gap: 6px; }
.vz-user { display: flex; align-items: center; gap: 10px; padding: 8px; border-radius: var(--vz-r-md); background: rgba(var(--vz-ov), 0.035); border: 1px solid var(--vz-bd); min-width: 0; }
.vz-avatar { width: 32px; height: 32px; flex: none; border-radius: calc(var(--vz-radius) * 0.8); overflow: hidden; display: block; }
.vz-avatar > * { width: 100%; height: 100%; }
.vz-user-meta { min-width: 0; flex: 1; }
.vz-user-meta p { font-size: 13px; font-weight: 600; line-height: 1.2; color: var(--vz-tx); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vz-user-meta small { font-size: 11px; color: var(--vz-tx3); }
.vz-icon-btn { width: 32px; height: 32px; flex: none; display: inline-flex; align-items: center; justify-content: center; border-radius: var(--vz-r-sm); color: var(--vz-tx2); background: transparent; border: 1px solid transparent; cursor: pointer; transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease, transform var(--vz-fast) ease; }
.vz-icon-btn:hover { background: rgba(var(--vz-ov), 0.08); color: var(--vz-tx); }
.vz-icon-btn:active { transform: scale(0.94); }
.vz-foot-btn { display: flex; align-items: center; gap: 12px; height: 34px; padding: 0 12px; border-radius: var(--vz-r-md); color: var(--vz-tx3); font-size: 13px; background: transparent; border: 0; cursor: pointer; text-align: left; transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease; }
.vz-foot-btn:hover { background: rgba(var(--vz-ov), 0.05); color: var(--vz-tx); }
.vz-foot-btn svg { width: 14px; flex: none; transition: transform var(--vz-slow) var(--vz-ease); }
html[data-vz-collapsed='1'] .vz-collapse svg { transform: rotate(180deg); }
.vz-scrim { display: none; }
.vz-only-mobile { display: none !important; }
@media (min-width: 1024px) {
    html[data-vz-collapsed='1'] .vz-side-head { justify-content: center; padding: 0; }
    html[data-vz-collapsed='1'] .vz-brand span, html[data-vz-collapsed='1'] .vz-item span, html[data-vz-collapsed='1'] .vz-nav-label,
    html[data-vz-collapsed='1'] .vz-user-meta, html[data-vz-collapsed='1'] .vz-foot-btn span { display: none; }
    html[data-vz-collapsed='1'] .vz-item, html[data-vz-collapsed='1'] .vz-foot-btn { justify-content: center; padding: 0; }
    html[data-vz-collapsed='1'] .vz-user { flex-direction: column; padding: 8px 4px; }
}

/* ============================================================ top bar + tabs */
.vz-topbar {
    position: sticky; top: 0; z-index: 30; height: var(--vz-top); display: flex; align-items: center; gap: 12px; padding: 0 24px;
    background: rgba(var(--vz-bg2-rgb), 0.74); -webkit-backdrop-filter: blur(16px) saturate(140%); backdrop-filter: blur(16px) saturate(140%); border-bottom: 1px solid var(--vz-bd);
}
.vz-crumbs { display: flex; align-items: center; gap: 8px; min-width: 0; flex: 1; font-size: 13px; list-style: none; margin: 0; padding: 0; }
.vz-crumbs li { display: flex; align-items: center; gap: 8px; color: var(--vz-tx3); white-space: nowrap; }
.vz-crumbs li + li::before { content: '/'; color: var(--vz-bd-strong); }
.vz-crumbs li:last-child { color: var(--vz-tx); font-weight: 500; }
.vz-crumbs a { color: var(--vz-tx3); text-decoration: none; } .vz-crumbs a:hover { color: var(--vz-tx); }
.vz-topbar-actions { display: flex; align-items: center; gap: 8px; }
.vz-search { display: inline-flex; align-items: center; gap: 10px; height: 34px; min-width: 240px; padding: 0 10px 0 12px; background: rgba(var(--vz-ov), 0.04); border: 1px solid var(--vz-bd); border-radius: var(--vz-r-md); color: var(--vz-tx3); font-size: 13px; cursor: pointer; transition: border-color var(--vz-fast) ease, background-color var(--vz-fast) ease, color var(--vz-fast) ease; }
.vz-search:hover { border-color: var(--vz-bd-strong); background: rgba(var(--vz-ov), 0.07); color: var(--vz-tx2); }
.vz-search span { flex: 1; text-align: left; }
.vz-search kbd { font-size: 11px; padding: 2px 6px; border-radius: 6px; border: 1px solid var(--vz-bd-strong); color: var(--vz-tx3); background: rgba(var(--vz-ov), 0.05); }
.vz-topbar + div:has(> div > a) { position: sticky; top: var(--vz-top); z-index: 20; background: rgba(var(--vz-bg2-rgb), 0.74) !important; box-shadow: none !important; -webkit-backdrop-filter: blur(14px); backdrop-filter: blur(14px); border-bottom: 1px solid var(--vz-bd); }
.vz-topbar + div:has(> div > a) > div { max-width: 1240px; padding: 0 12px; }
.vz-topbar + div:has(> div > a) > div > a, .vz-topbar + div:has(> div > a) > div > div { position: relative; margin: 0 !important; padding: 13px 14px !important; color: var(--vz-tx3) !important; font-weight: 500; box-shadow: none !important; border: 0 !important; transition: color var(--vz-fast) ease !important; }
.vz-topbar + div:has(> div > a) > div > a:hover { color: var(--vz-tx) !important; }
.vz-topbar + div:has(> div > a) > div > a::after { content: ''; position: absolute; left: 14px; right: 14px; bottom: -1px; height: 2px; border-radius: 2px; background: var(--vz-accent); transform: scaleX(0); transition: transform var(--vz-base) var(--vz-ease); }
.vz-topbar + div:has(> div > a) > div > a.active { color: var(--vz-tx) !important; }
.vz-topbar + div:has(> div > a) > div > a.active::after { transform: scaleX(1); }

/* ============================================================ page */
[class*='ContentContainer-sc'], [class^='ContentContainer'] { box-sizing: border-box; max-width: 1240px !important; padding-left: clamp(16px, 2.4vw, 32px); padding-right: clamp(16px, 2.4vw, 32px); margin-left: auto !important; margin-right: auto !important; }
.vz-page-head { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; margin-bottom: 20px; }
.vz-page-head h1 { font-size: 26px; font-weight: 600; line-height: 1.15; }
.vz-page-head p { margin-top: 4px; font-size: 12.5px; color: var(--vz-tx3); font-family: var(--vz-mono); }
.fade-enter { opacity: 0; transform: translateY(8px); }
.fade-enter-active { opacity: 1; transform: none; transition: opacity 220ms ease, transform 260ms var(--vz-ease); }
.fade-exit { opacity: 1; }
.fade-exit-active { opacity: 0; transition: opacity 120ms ease; }

/* ============================================================ surfaces */
[class*='GreyRowBox'], a[class*='ServerRow__StatusIndicatorBox'] {
    background: var(--vz-surface) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-lg) !important; box-shadow: var(--vz-sh1);
    transition: transform var(--vz-base) var(--vz-ease), border-color var(--vz-fast) ease, background-color var(--vz-fast) ease, box-shadow var(--vz-base) ease !important;
}
a[class*='ServerRow__StatusIndicatorBox'] { padding: 16px 20px !important; }
a[class*='ServerRow__StatusIndicatorBox']:hover, [class*='GreyRowBox']:hover { background: var(--vz-elev) !important; border-color: var(--vz-bd-strong); transform: translateY(-1px) scale(1.002); box-shadow: var(--vz-sh2); }
[class^='ServerRow__Icon-sc'], [class*=' ServerRow__Icon-sc'], .icon { background: rgba(var(--vz-ov), 0.045) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-md) !important; }
[class*='ServerRow__StatusIndicatorBox'] .status-bar { width: 8px !important; height: 8px !important; top: 50%; right: 18px !important; margin: 0 !important; transform: translateY(-50%); border-radius: 50% !important; opacity: 1 !important; box-shadow: 0 0 0 3px rgba(var(--vz-ov), 0.06); }
.vz-meter { height: 3px; margin: 7px auto 0; width: 76px; border-radius: 3px; background: rgba(var(--vz-ov), 0.1); overflow: hidden; }
.vz-meter i { display: block; height: 100%; width: 0; border-radius: inherit; background: var(--vz-accent); transition: width var(--vz-slow) var(--vz-ease), background-color var(--vz-base) ease; }
.vz-meter i[data-alarm='1'] { background: var(--vz-err); }
[class*='TitledGreyBox___StyledDiv']:not([class*='StyledDiv2']):not([class*='StyledDiv3']) { background: var(--vz-surface) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-lg) !important; box-shadow: var(--vz-sh1); overflow: hidden; }
[class*='TitledGreyBox___StyledDiv2'] { background: var(--vz-elev) !important; border-bottom: 1px solid var(--vz-bd); padding: 12px 16px !important; font-size: 13px; font-weight: 500; }
[class*='ContentBox___Styled'] > h2 { font-size: 13px; font-weight: 600; letter-spacing: 0.01em; color: var(--vz-tx2) !important; padding: 0 2px !important; margin-bottom: 10px !important; }
[class*='ContentBox___Styled'] > div:last-child { background: var(--vz-surface) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-lg) !important; box-shadow: var(--vz-sh1) !important; padding: 18px !important; }
html[data-vz-density='compact'] [class*='ContentBox___Styled'] > div:last-child { padding: 14px !important; }
.vz-skeleton-list { display: flex; flex-direction: column; gap: 8px; }
.vz-skel { height: 76px; border-radius: var(--vz-r-lg); border: 1px solid var(--vz-bd); background: linear-gradient(100deg, var(--vz-surface) 30%, var(--vz-elev) 50%, var(--vz-surface) 70%); background-size: 250% 100%; animation: vzShimmer 2.2s ease-in-out infinite; }

.vz-dialog-scrim { background: rgba(var(--vz-scrim), 0.55); -webkit-backdrop-filter: blur(4px); backdrop-filter: blur(4px); }
/* ============================================================ controls */
[class*='Button__ButtonStyle'] { border-radius: var(--vz-r-md) !important; font-weight: 500 !important; letter-spacing: 0 !important; border-width: 1px !important; transition: transform var(--vz-fast) ease, filter var(--vz-fast) ease, box-shadow var(--vz-base) ease, background-color var(--vz-fast) ease, border-color var(--vz-fast) ease !important; }
[class*='Button__ButtonStyle']:hover:not(:disabled) { filter: brightness(1.08); }
[class*='Button__ButtonStyle']:active:not(:disabled), button:active:not(:disabled) { transform: scale(0.97); }
[class*='Button__ButtonStyle']:disabled { opacity: 0.5; cursor: not-allowed; }
input:not([type='checkbox']):not([type='radio']):not([type='file']):not([type='range']):not([type='color']), textarea, select {
    background-color: rgba(var(--vz-ov), 0.04) !important; border: 1px solid var(--vz-bd-strong) !important; border-radius: var(--vz-r-md) !important; color: var(--vz-tx) !important;
    transition: border-color var(--vz-fast) ease, box-shadow var(--vz-base) ease, background-color var(--vz-fast) ease !important;
}
input:not([type='checkbox']):not([type='radio']):not([type='file']):not([type='range']):not([type='color']):hover, textarea:hover, select:hover { border-color: rgba(var(--vz-ov), 0.28) !important; }
input:not([type='checkbox']):not([type='radio']):not([type='file']):not([type='range']):not([type='color']):focus, textarea:focus, select:focus { border-color: var(--vz-accent) !important; background-color: rgba(var(--vz-acc-rgb), 0.06) !important; box-shadow: 0 0 0 3px rgba(var(--vz-acc-rgb), 0.2) !important; }
input::placeholder, textarea::placeholder { color: var(--vz-tx3) !important; opacity: 0.8; }
input:disabled, textarea:disabled, select:disabled { opacity: 0.55; cursor: not-allowed; }
input[type='checkbox'], input[type='radio'], input[type='range'] { accent-color: var(--vz-accent); }
label, [class*='Label-sc'] { color: var(--vz-tx2); font-weight: 500; }
[class*='InputError'] { color: var(--vz-err) !important; }
[class*='Switch__ToggleContainer'], [class*='Switch___StyledToggleContainer'] { transition: background-color var(--vz-base) ease !important; }
[class*='Switch__ToggleContainer'] > *, [class*='Switch___StyledToggleContainer'] > * { transition: transform var(--vz-base) var(--vz-ease), background-color var(--vz-base) ease !important; }
[class*='ProgressBar'] { border-radius: 99px !important; height: 4px !important; }
[class*='ProgressBar__BarFill'] { border-radius: 99px !important; transition: width var(--vz-slow) var(--vz-ease) !important; }
[class*='SpinnerOverlay___StyledDiv'] { -webkit-backdrop-filter: blur(4px); backdrop-filter: blur(4px); }

/* ============================================================ overlays */
[class*='Modal__ModalMask'] { background: rgba(var(--vz-scrim), 0.62) !important; -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); }
[class*='Modal__ModalContainer'] { background: var(--vz-elev) !important; border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-xl) !important; box-shadow: var(--vz-sh3) !important; animation: vzModal 200ms var(--vz-ease) backwards; }
@media (max-width: 640px) { [class*='Modal__ModalContainer'] { width: calc(100vw - 24px) !important; max-height: calc(100vh - 24px); overflow-y: auto; } }
[class*='DropdownMenu___StyledDiv'] { background: var(--vz-elev2) !important; border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-lg) !important; box-shadow: var(--vz-sh2) !important; animation: vzPop 140ms var(--vz-ease) backwards; transform-origin: top right; }
[class*='DropdownMenu__DropdownButtonRow'], [class*='FileDropdownMenu__StyledRow'] { border-radius: var(--vz-r-sm) !important; transition: background-color var(--vz-fast) ease !important; }
[role='tooltip'] { border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-sm) !important; background: var(--vz-elev2) !important; color: var(--vz-tx) !important; box-shadow: var(--vz-sh2); font-size: 12px; }
[class*='MessageBox__Container'] { border-radius: var(--vz-r-md) !important; border: 1px solid var(--vz-bd-strong) !important; background: var(--vz-elev) !important; box-shadow: var(--vz-sh2); animation: vzSlide 260ms var(--vz-ease) backwards; }

/* ============================================================ console / files / editor / charts */
.xterm { padding: 12px 14px; font-family: var(--vz-mono) !important; }
div:has(> .xterm) { background: var(--vz-console) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-lg); overflow: hidden; }
[class*='FileObjectRow___StyledDiv'] { border-radius: var(--vz-r-sm); transition: background-color var(--vz-fast) ease !important; }
[class*='FileObjectRow___StyledDiv']:hover { background: rgba(var(--vz-ov), 0.05) !important; }
.cm-editor, [class*='CodemirrorEditor'] { border-radius: var(--vz-r-lg); font-family: var(--vz-mono) !important; }
canvas { border-radius: var(--vz-r-sm); }
table { border-collapse: collapse; }
th { color: var(--vz-tx3); font-weight: 500; font-size: 11px; text-transform: uppercase; letter-spacing: 0.06em; }
tbody tr { border-top: 1px solid var(--vz-bd); transition: background-color var(--vz-fast) ease; } tbody tr:hover { background: rgba(var(--vz-ov), 0.04); }

/* ============================================================ auth (login, forgot password, reset, two-step) */
.vz-auth { min-height: 100vh; display: flex; flex-direction: column; }
.vz-auth-top { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 22px clamp(18px, 3vw, 44px); animation: vzSlide 500ms var(--vz-ease) backwards; }
.vz-auth-brand { display: inline-flex; align-items: center; gap: 12px; min-width: 0; color: var(--vz-tx); font-size: 16px; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase; text-decoration: none; }
.vz-auth-logo { flex: none; display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; border-radius: var(--vz-r-md); background: var(--vz-accent); box-shadow: 0 6px 18px -8px rgba(var(--vz-acc-rgb), 0.7); }
.vz-auth-logo img { width: 18px; height: 18px; filter: brightness(0) invert(1); }
.vz-auth-brand span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vz-auth-links { display: flex; align-items: center; gap: 6px; }
.vz-auth-links a { display: inline-flex; align-items: center; gap: 8px; height: 34px; padding: 0 12px; border-radius: var(--vz-r-sm); color: var(--vz-tx2); font-size: 14px; font-weight: 500; text-decoration: none; transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease; }
.vz-auth-links a:hover { background: rgba(var(--vz-ov), 0.08); color: var(--vz-tx); }
.vz-auth-links svg { width: 15px; }
.vz-auth-main { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 16px 16px 56px; }
.vz-auth-card { width: min(100%, 440px); padding: 28px; box-sizing: border-box; background: rgba(var(--vz-surface-rgb), 0.8); border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-xl); box-shadow: var(--vz-sh3); -webkit-backdrop-filter: blur(18px); backdrop-filter: blur(18px); animation: vzModal 460ms var(--vz-ease) backwards; }
.vz-auth-card h2 { margin: 0 0 20px; font-size: 19px; font-weight: 600; text-align: left; }
.vz-auth-flash { margin-bottom: 12px; }
.vz-auth-form { width: 100%; display: block; }
.vz-auth-form > * { animation: vzRise 460ms var(--vz-ease) backwards; }
.vz-auth-form > *:nth-child(2) { animation-delay: 50ms; } .vz-auth-form > *:nth-child(3) { animation-delay: 100ms; } .vz-auth-form > *:nth-child(4) { animation-delay: 150ms; }
.vz-auth-form label { display: block; margin-bottom: 8px; font-size: 13px; line-height: 18px; color: var(--vz-tx2) !important; }
.vz-auth-form input[type='text'], .vz-auth-form input[type='password'], .vz-auth-form input[type='email'] { width: 100%; height: 46px; padding: 0 14px 0 44px !important; box-sizing: border-box; }
.vz-auth-form input[name='username'], .vz-auth-form input[name='email'] { background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='%238a93a3' stroke-width='1.8' stroke-linecap='round'%3E%3Ccircle cx='12' cy='8' r='4'/%3E%3Cpath d='M4 21c0-4 3.6-7 8-7s8 3 8 7'/%3E%3C/svg%3E") 14px center / 18px no-repeat; }
.vz-auth-form input[name='password'], .vz-auth-form input[name='password_confirmation'] { background: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='%238a93a3' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='8' cy='15' r='4'/%3E%3Cpath d='M11 12l9-9M16 7l3 3M14 9l2 2'/%3E%3C/svg%3E") 14px center / 18px no-repeat; }
.vz-auth-pw { position: relative; }
.vz-auth-forgot { position: absolute; top: 0; right: 0; font-size: 12.5px; line-height: 18px; color: var(--vz-tx3) !important; text-decoration: underline; text-underline-offset: 3px; }
.vz-auth-forgot:hover { color: var(--vz-accent-h) !important; }
.vz-auth-eye { position: absolute; right: 6px; top: 26px; width: 34px; height: 46px; display: inline-flex; align-items: center; justify-content: center; background: none; border: 0; color: var(--vz-tx3); cursor: pointer; transition: color var(--vz-fast) ease; }
.vz-auth-eye:hover { color: var(--vz-tx); }
.vz-auth-pw input[name='password'] { padding-right: 44px !important; }
.vz-auth-form button[type='submit'], .vz-auth-form [class*='Button__ButtonStyle'] { width: 100%; height: 46px; }
.vz-auth-foot { margin-top: 24px; font-size: 12px; color: var(--vz-tx3); text-align: center; }
.vz-auth-foot a { color: var(--vz-tx3); text-decoration: none; } .vz-auth-foot a:hover { color: var(--vz-tx2); }
@media (max-width: 640px) { .vz-auth-links a span { display: none; } .vz-auth-card { padding: 22px; } }

/* ============================================================ server card picture (Admin → Appearance → Server cards) */
html[data-vz-cards='1'] a[class*='ServerRow__StatusIndicatorBox'] { position: relative; isolation: isolate; overflow: hidden; }
html[data-vz-cards='1'] a[class*='ServerRow__StatusIndicatorBox']::before { content: ''; position: absolute; inset: -8px; z-index: -2; background: var(--vz-card-image) center / cover no-repeat; filter: blur(var(--vz-card-blur)); transition: transform 700ms var(--vz-ease); }
html[data-vz-cards='1'] a[class*='ServerRow__StatusIndicatorBox']::after { content: ''; position: absolute; inset: 0; z-index: -1; background: linear-gradient(90deg, rgba(var(--vz-surface-rgb), calc(var(--vz-card-dim) + 0.1)) 0%, rgba(var(--vz-surface-rgb), var(--vz-card-dim)) 55%, rgba(var(--vz-surface-rgb), calc(var(--vz-card-dim) * 0.88)) 100%); }
html[data-vz-cards='1'][data-vz-mode='dark'] a[class*='ServerRow__StatusIndicatorBox'], html[data-vz-cards='1'][data-vz-mode='oled'] a[class*='ServerRow__StatusIndicatorBox'] { text-shadow: 0 1px 3px rgba(0, 0, 0, 0.55); }
html[data-vz-cards='1'] a[class*='ServerRow__StatusIndicatorBox']:hover::before { transform: scale(1.05); }

/* custom logo (Admin → Appearance → Branding): shown as uploaded, no recolouring */
.vz-brand img.vz-custom { filter: none !important; opacity: 1 !important; width: auto; max-width: 140px; height: 28px; object-fit: contain; }
.vz-auth-logo.vz-custom { background: none; box-shadow: none; width: auto; }
.vz-auth-logo.vz-custom img { filter: none; width: auto; max-width: 160px; height: 34px; object-fit: contain; }
/* sign-in wallpaper (Admin → Appearance → Branding) */
html[data-vz-login='1'] .vz-auth { position: relative; isolation: isolate; }
html[data-vz-login='1'] .vz-auth::before { content: ''; position: fixed; inset: -20px; z-index: -2; background: var(--vz-login-image) center / cover no-repeat; filter: blur(var(--vz-login-blur)); }
html[data-vz-login='1'] .vz-auth::after { content: ''; position: fixed; inset: 0; z-index: -1; background: rgba(0, 0, 0, var(--vz-login-dim)); }
html[data-vz-login='1'] .vz-auth-top, html[data-vz-login='1'] .vz-auth-foot { --vz-tx: #F5F7FA; --vz-tx2: #C9CFD9; --vz-tx3: #A8B0BD; --vz-ov: 255, 255, 255; }
html[data-vz-login='1'] .vz-auth-brand img { filter: none; }


/* ============================================================ big server cards (Minecraft / Node.js banners) */
.vz-card-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
@media (max-width: 900px) { .vz-card-grid { grid-template-columns: minmax(0, 1fr); } }
a.vz-bigcard { display: flex !important; flex-direction: column; justify-content: space-between; gap: 18px; min-height: 210px; padding: 18px 20px !important; position: relative; isolation: isolate; overflow: hidden; border-radius: calc(var(--vz-radius) * 1.2) !important; margin: 0 !important; background-color: #0b0f14; background-size: cover; background-position: center; transition: transform var(--vz-base) var(--vz-ease), box-shadow var(--vz-base) var(--vz-ease), border-color var(--vz-fast) ease; text-shadow: 0 1px 3px rgba(0, 0, 0, 0.7); color: #F5F7FA; }
/* the base theme sets `background: ... !important` on server rows, so the banner must be !important too (also on hover) */
a.vz-bigcard[data-kind], a.vz-bigcard[data-kind]:hover { background-color: #0b0f14 !important; background-size: cover !important; background-position: center !important; background-repeat: no-repeat !important; }
a.vz-bigcard[data-kind='minecraft'], a.vz-bigcard[data-kind='minecraft']:hover { background-image: url('/vizion/card-minecraft.jpg') !important; }
a.vz-bigcard[data-kind='nodejs'], a.vz-bigcard[data-kind='nodejs']:hover { background-image: url('/vizion/card-nodejs.jpg') !important; }
a.vz-bigcard::before { content: ''; position: absolute; inset: 0; z-index: -1; background: linear-gradient(180deg, rgba(0, 0, 0, 0.35) 0%, rgba(0, 0, 0, 0.6) 100%); }
a.vz-bigcard[data-kind='nodejs']::before { background: linear-gradient(180deg, rgba(20, 70, 25, 0.35) 0%, rgba(0, 0, 0, 0.6) 100%); }
a.vz-bigcard:hover { transform: translateY(-3px) !important; box-shadow: 0 12px 30px rgba(0, 0, 0, 0.45); }
a.vz-bigcard .vz-card-head { display: flex; align-items: flex-start; gap: 12px; min-width: 0; }
a.vz-bigcard .vz-card-name { font-size: 17px; font-weight: 600; color: #fff; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
a.vz-bigcard .vz-card-desc { font-size: 12.5px; color: rgba(255, 255, 255, 0.78); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
a.vz-bigcard .vz-card-ip { margin-left: auto; flex: none; font-size: 12px; padding: 3px 9px; border-radius: 999px; background: rgba(0, 0, 0, 0.45); color: rgba(255, 255, 255, 0.9); }
a.vz-bigcard .vz-card-stats { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; align-items: end; margin-top: auto; padding: 12px; border-radius: var(--vz-r-md); background: rgba(0, 0, 0, 0.45); -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); }
a.vz-bigcard .vz-stat-top { display: flex; align-items: center; gap: 6px; font-size: 12px; }
a.vz-bigcard .vz-stat-label { color: rgba(255, 255, 255, 0.75); }
a.vz-bigcard .vz-stat-top b { margin-left: auto; font-size: 18px; font-weight: 700; color: #fff; }
a.vz-bigcard .vz-meter { width: 100%; height: 5px; margin: 6px 0 4px; background: rgba(255, 255, 255, 0.18); }
a.vz-bigcard .vz-stat small { font-size: 10.5px; color: rgba(255, 255, 255, 0.65); }
a.vz-bigcard .status-bar { z-index: 2; }
html[data-vz-cards] a.vz-bigcard::before { inset: 0; filter: none; transform: none; background: linear-gradient(180deg, rgba(0, 0, 0, 0.35) 0%, rgba(0, 0, 0, 0.6) 100%); }
html[data-vz-cards] a.vz-bigcard[data-kind='nodejs']::before { background: linear-gradient(180deg, rgba(20, 70, 25, 0.35) 0%, rgba(0, 0, 0, 0.6) 100%); }
html[data-vz-cards] a.vz-bigcard::after { display: none; }

/* ============================================================ announcement + quick links */
.vz-ann { position: relative; display: flex; align-items: center; gap: 12px; padding: 10px clamp(16px, 2.4vw, 32px); font-size: 13px; color: var(--vz-tx); background: rgba(var(--vz-ann, var(--vz-acc-rgb)), 0.1); border-bottom: 1px solid rgba(var(--vz-ann, var(--vz-acc-rgb)), 0.28); animation: vzSlide 320ms var(--vz-ease) backwards; }
.vz-ann[data-type='success'] { --vz-ann: 63, 178, 127; } .vz-ann[data-type='warning'] { --vz-ann: 224, 163, 58; } .vz-ann[data-type='danger'] { --vz-ann: 229, 96, 90; }
.vz-ann::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 3px; background: rgb(var(--vz-ann, var(--vz-acc-rgb))); }
.vz-ann-icon { flex: none; color: rgb(var(--vz-ann, var(--vz-acc-rgb))); }
.vz-ann p { flex: 1; min-width: 0; line-height: 1.45; } .vz-ann strong { font-weight: 600; margin-right: 8px; } .vz-ann span { color: var(--vz-tx2); }
.vz-ann-link { flex: none; padding: 4px 10px; border-radius: var(--vz-r-sm); border: 1px solid rgba(var(--vz-ann, var(--vz-acc-rgb)), 0.4); color: var(--vz-tx); text-decoration: none; font-weight: 500; transition: background-color var(--vz-fast) ease; }
.vz-ann-link:hover { background: rgba(var(--vz-ann, var(--vz-acc-rgb)), 0.16); }
.vz-ann + div:has(> div > a) { position: sticky; top: var(--vz-top); z-index: 20; background: rgba(var(--vz-bg2-rgb), 0.74) !important; box-shadow: none !important; -webkit-backdrop-filter: blur(14px); backdrop-filter: blur(14px); border-bottom: 1px solid var(--vz-bd); }
.vz-ann + div:has(> div > a) > div { max-width: 1240px; padding: 0 12px; }
.vz-ann + div:has(> div > a) > div > a { position: relative; margin: 0 !important; padding: 13px 14px !important; color: var(--vz-tx3) !important; font-weight: 500; box-shadow: none !important; border: 0 !important; }
.vz-ann + div:has(> div > a) > div > a.active { color: var(--vz-tx) !important; }
.vz-ann + div:has(> div > a) > div > a::after { content: ''; position: absolute; left: 14px; right: 14px; bottom: -1px; height: 2px; border-radius: 2px; background: var(--vz-accent); transform: scaleX(0); transition: transform var(--vz-base) var(--vz-ease); }
.vz-ann + div:has(> div > a) > div > a.active::after { transform: scaleX(1); }
.vz-links { display: flex; align-items: center; gap: 4px; margin-right: 4px; }
.vz-links a { display: inline-flex; align-items: center; gap: 8px; height: 32px; padding: 0 10px; border-radius: var(--vz-r-sm); color: var(--vz-tx2); font-size: 13px; font-weight: 500; text-decoration: none; transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease; }
.vz-links a:hover { background: rgba(var(--vz-ov), 0.07); color: var(--vz-tx); }
.vz-links svg { width: 14px; color: var(--vz-tx3); }
@media (max-width: 1180px) { .vz-links { display: none; } }
@media (min-width: 1181px) { .vz-nav-links { display: none !important; } }

/* ============================================================ motion */
@keyframes vzRise { from { opacity: 0; transform: translateY(10px); } }
@keyframes vzModal { from { opacity: 0; transform: translateY(8px) scale(0.97); } }
@keyframes vzPop { from { opacity: 0; transform: scale(0.96); } }
@keyframes vzSlide { from { opacity: 0; transform: translateY(-8px); } }
@keyframes vzShimmer { from { background-position: 150% 0; } to { background-position: -50% 0; } }
html[data-vz-density='compact'] a[class*='ServerRow__StatusIndicatorBox'] { padding: 10px 16px !important; }

/* ============================================================ responsive */
@media (max-width: 1023px) {
    .vz-only-mobile { display: inline-flex !important; }
    .vz-only-desktop { display: none !important; }
    .vz-side { width: 272px; transform: translateX(-102%); box-shadow: none; z-index: 60; }
    .vz-side[data-open='1'] { transform: none; box-shadow: var(--vz-sh3); }
    .vz-scrim { display: block; position: fixed; inset: 0; z-index: 55; background: rgba(var(--vz-scrim), 0.6); -webkit-backdrop-filter: blur(3px); backdrop-filter: blur(3px); opacity: 0; pointer-events: none; transition: opacity var(--vz-base) ease; }
    .vz-scrim[data-open='1'] { opacity: 1; pointer-events: auto; }
    .vz-topbar { padding: 0 14px; }
    .vz-search { min-width: 0; width: 34px; padding: 0; justify-content: center; }
    .vz-search span, .vz-search kbd { display: none; }
}
@media (max-width: 640px) {
    .vz-page-head { flex-direction: column; align-items: flex-start; }
    .vz-page-head h1 { font-size: 22px; }
    a[class*='ServerRow__StatusIndicatorBox'] { padding: 14px 40px 14px 14px !important; }
    .vz-ae { width: 100vw; }
}
@media (prefers-reduced-motion: reduce) { *, *::before, *::after { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; scroll-behavior: auto !important; } }
html[data-vz-motion='reduced'] *, html[data-vz-motion='reduced'] *::before, html[data-vz-motion='reduced'] *::after { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; scroll-behavior: auto !important; }
`;
