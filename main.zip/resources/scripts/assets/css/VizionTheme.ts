import { createGlobalStyle } from 'styled-components/macro';

/**
 * Vizion design system.
 * Colour palette lives in tailwind.config.js (gray / primary ramps) so every existing component is themed
 * automatically; this file adds tokens, layout, elevation, motion and component polish on top.
 */
export default createGlobalStyle`
:root {
    --vz-bg: #07090D;
    --vz-bg2: #0A0E14;
    --vz-surface: #10151D;
    --vz-elev: #141A23;
    --vz-elev2: #181F2A;
    --vz-bd: rgba(255, 255, 255, 0.06);
    --vz-bd-strong: rgba(255, 255, 255, 0.11);
    --vz-tx: #F5F7FA;
    --vz-tx2: #A8B0BD;
    --vz-tx3: #687282;
    --vz-accent: #4F8CFF;
    --vz-accent-h: #6A9CFF;
    --vz-accent-bg: rgba(79, 140, 255, 0.12);
    --vz-ok: #3FB27F;
    --vz-warn: #E0A33A;
    --vz-err: #E5605A;
    --vz-r-sm: 8px;
    --vz-r-md: 10px;
    --vz-r-lg: 14px;
    --vz-r-xl: 18px;
    --vz-ease: cubic-bezier(0.22, 1, 0.36, 1);
    --vz-fast: 140ms;
    --vz-base: 200ms;
    --vz-slow: 300ms;
    --vz-sh1: 0 1px 2px rgba(0, 0, 0, 0.35);
    --vz-sh2: 0 8px 24px -10px rgba(0, 0, 0, 0.6);
    --vz-sh3: 0 24px 64px -16px rgba(0, 0, 0, 0.75);
    --vz-sw: 248px;
    --vz-top: 56px;
    --vz-mono: 'JetBrains Mono', 'SF Mono', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
}
html[data-vz-collapsed='1'] { --vz-sw: 68px; }
@media (max-width: 1023px) { :root, html[data-vz-collapsed='1'] { --vz-sw: 0px; } }

html { color-scheme: dark; background: var(--vz-bg); }
body {
    background: transparent !important;
    letter-spacing: 0;
    -webkit-font-smoothing: antialiased;
    text-rendering: optimizeLegibility;
}
body::before {
    content: '';
    position: fixed;
    inset: 0;
    z-index: -1;
    pointer-events: none;
    background:
        radial-gradient(900px 520px at 12% -8%, rgba(79, 140, 255, 0.07), transparent 70%),
        radial-gradient(700px 480px at 100% 0%, rgba(120, 140, 200, 0.045), transparent 70%),
        linear-gradient(180deg, var(--vz-bg2), var(--vz-bg));
}
::selection { background: rgba(79, 140, 255, 0.4); color: #fff; }
* { scrollbar-width: thin; scrollbar-color: #232c3a transparent; }
::-webkit-scrollbar { width: 8px; height: 8px; background: none; }
::-webkit-scrollbar-thumb { background: #232c3a; border-radius: 8px; }
::-webkit-scrollbar-thumb:hover { background: #313c4e; }
:focus-visible { outline: 2px solid rgba(79, 140, 255, 0.65); outline-offset: 2px; }
h1, h2, h3, h4 { letter-spacing: -0.01em; color: var(--vz-tx); }
code, pre, kbd, samp { font-family: var(--vz-mono); }
a { transition: color var(--vz-fast) ease, opacity var(--vz-fast) ease; }

/* ---------------------------------------------------------------- shell */
.vz-shell #app { padding-left: var(--vz-sw); transition: padding-left var(--vz-slow) var(--vz-ease); }
.vz-side {
    position: fixed; inset: 0 auto 0 0; width: var(--vz-sw); z-index: 40;
    display: flex; flex-direction: column;
    background: rgba(10, 14, 20, 0.86);
    -webkit-backdrop-filter: blur(18px); backdrop-filter: blur(18px);
    border-right: 1px solid var(--vz-bd);
    transition: width var(--vz-slow) var(--vz-ease), transform var(--vz-slow) var(--vz-ease);
    overflow: hidden;
}
.vz-side-head { display: flex; align-items: center; justify-content: space-between; height: var(--vz-top); padding: 0 16px; border-bottom: 1px solid var(--vz-bd); flex: none; }
.vz-brand { display: flex; align-items: center; gap: 10px; min-width: 0; color: var(--vz-tx); text-decoration: none; font-weight: 600; font-size: 15px; letter-spacing: -0.01em; }
.vz-brand img { width: 24px; height: 24px; flex: none; filter: brightness(0) invert(1); opacity: 0.92; }
.vz-brand span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; transition: opacity var(--vz-base) ease; }
.vz-nav { position: relative; flex: 1; padding: 14px 10px; display: flex; flex-direction: column; gap: 2px; overflow-y: auto; overflow-x: hidden; }
.vz-nav-label { padding: 0 10px 8px; font-size: 11px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.08em; color: var(--vz-tx3) !important; white-space: nowrap; transition: opacity var(--vz-base) ease; }
.vz-item {
    position: relative; display: flex; align-items: center; gap: 12px; height: 38px; padding: 0 12px;
    border-radius: var(--vz-r-md); color: var(--vz-tx2); font-size: 14px; font-weight: 500; text-decoration: none; white-space: nowrap;
    border: 1px solid transparent;
    transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease, border-color var(--vz-fast) ease;
}
.vz-item svg { width: 16px; height: 16px; flex: none; color: var(--vz-tx3); transition: color var(--vz-fast) ease, transform var(--vz-base) var(--vz-ease); }
.vz-item:hover { background: rgba(255, 255, 255, 0.045); color: var(--vz-tx); }
.vz-item:hover svg { color: var(--vz-tx2); transform: translateX(1px); }
.vz-item.active { background: var(--vz-accent-bg); border-color: rgba(79, 140, 255, 0.2); color: #fff; }
.vz-item.active svg { color: var(--vz-accent-h); }
.vz-ind {
    position: absolute; left: 0; top: 0; width: 3px; border-radius: 0 3px 3px 0; background: var(--vz-accent);
    box-shadow: 0 0 12px rgba(79, 140, 255, 0.55); pointer-events: none;
    transition: transform var(--vz-slow) var(--vz-ease), height var(--vz-slow) var(--vz-ease), opacity var(--vz-base) ease;
}
.vz-side-foot { flex: none; padding: 10px; border-top: 1px solid var(--vz-bd); display: flex; flex-direction: column; gap: 8px; }
.vz-user { display: flex; align-items: center; gap: 10px; padding: 8px; border-radius: var(--vz-r-md); background: rgba(255, 255, 255, 0.03); border: 1px solid var(--vz-bd); min-width: 0; }
.vz-avatar { width: 32px; height: 32px; flex: none; border-radius: 8px; overflow: hidden; display: block; }
.vz-avatar > * { width: 100%; height: 100%; }
.vz-user-meta { min-width: 0; flex: 1; }
.vz-user-meta p { font-size: 13px; font-weight: 600; line-height: 1.2; color: var(--vz-tx); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.vz-user-meta small { font-size: 11px; color: var(--vz-tx3); }
.vz-icon-btn { width: 32px; height: 32px; flex: none; display: inline-flex; align-items: center; justify-content: center; border-radius: var(--vz-r-sm); color: var(--vz-tx2); background: transparent; border: 1px solid transparent; cursor: pointer; transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease, transform var(--vz-fast) ease; }
.vz-icon-btn:hover { background: rgba(255, 255, 255, 0.07); color: var(--vz-tx); }
.vz-icon-btn:active { transform: scale(0.94); }
.vz-collapse { display: flex; align-items: center; gap: 12px; height: 34px; padding: 0 12px; border-radius: var(--vz-r-md); color: var(--vz-tx3); font-size: 13px; background: transparent; border: 0; cursor: pointer; transition: background-color var(--vz-fast) ease, color var(--vz-fast) ease; }
.vz-collapse:hover { background: rgba(255, 255, 255, 0.045); color: var(--vz-tx2); }
.vz-collapse svg { width: 14px; transition: transform var(--vz-slow) var(--vz-ease); }
html[data-vz-collapsed='1'] .vz-collapse svg { transform: rotate(180deg); }
.vz-scrim { display: none; }
.vz-only-mobile { display: none !important; }

/* collapsed rail (desktop) */
@media (min-width: 1024px) {
    html[data-vz-collapsed='1'] .vz-side-head { justify-content: center; padding: 0; }
    html[data-vz-collapsed='1'] .vz-brand span,
    html[data-vz-collapsed='1'] .vz-item span,
    html[data-vz-collapsed='1'] .vz-nav-label,
    html[data-vz-collapsed='1'] .vz-user-meta,
    html[data-vz-collapsed='1'] .vz-collapse span { display: none; }
    html[data-vz-collapsed='1'] .vz-item { justify-content: center; padding: 0; }
    html[data-vz-collapsed='1'] .vz-user { flex-direction: column; padding: 8px 4px; }
    html[data-vz-collapsed='1'] .vz-collapse { justify-content: center; padding: 0; }
}

/* ---------------------------------------------------------------- top bar */
.vz-topbar {
    position: sticky; top: 0; z-index: 30; height: var(--vz-top); display: flex; align-items: center; gap: 12px; padding: 0 24px;
    background: rgba(10, 14, 20, 0.72); -webkit-backdrop-filter: blur(16px) saturate(140%); backdrop-filter: blur(16px) saturate(140%);
    border-bottom: 1px solid var(--vz-bd);
}
.vz-crumbs { display: flex; align-items: center; gap: 8px; min-width: 0; flex: 1; font-size: 13px; list-style: none; margin: 0; padding: 0; }
.vz-crumbs li { display: flex; align-items: center; gap: 8px; color: var(--vz-tx3); white-space: nowrap; }
.vz-crumbs li + li::before { content: '/'; color: var(--vz-bd-strong); }
.vz-crumbs li:last-child { color: var(--vz-tx); font-weight: 500; }
.vz-crumbs a { color: var(--vz-tx3); text-decoration: none; } .vz-crumbs a:hover { color: var(--vz-tx); }
.vz-topbar-actions { display: flex; align-items: center; gap: 8px; }
.vz-search {
    display: inline-flex; align-items: center; gap: 10px; height: 34px; min-width: 240px; padding: 0 10px 0 12px;
    background: rgba(255, 255, 255, 0.04); border: 1px solid var(--vz-bd); border-radius: var(--vz-r-md);
    color: var(--vz-tx3); font-size: 13px; cursor: pointer; transition: border-color var(--vz-fast) ease, background-color var(--vz-fast) ease, color var(--vz-fast) ease;
}
.vz-search:hover { border-color: var(--vz-bd-strong); background: rgba(255, 255, 255, 0.07); color: var(--vz-tx2); }
.vz-search span { flex: 1; text-align: left; }
.vz-search kbd { font-size: 11px; padding: 2px 6px; border-radius: 6px; border: 1px solid var(--vz-bd-strong); color: var(--vz-tx3); background: rgba(0, 0, 0, 0.25); }

/* server / account sub navigation (tabs) */
.vz-topbar + div:has(> div > a) {
    position: sticky; top: var(--vz-top); z-index: 20; background: rgba(10, 14, 20, 0.72) !important; box-shadow: none !important;
    -webkit-backdrop-filter: blur(14px); backdrop-filter: blur(14px); border-bottom: 1px solid var(--vz-bd);
}
.vz-topbar + div:has(> div > a) > div { max-width: 1200px; padding: 0 12px; }
.vz-topbar + div:has(> div > a) > div > a,
.vz-topbar + div:has(> div > a) > div > div {
    position: relative; margin: 0 !important; padding: 13px 14px !important; color: var(--vz-tx3) !important; font-weight: 500; box-shadow: none !important;
    transition: color var(--vz-fast) ease, background-color var(--vz-fast) ease !important;
}
.vz-topbar + div:has(> div > a) > div > a:hover { color: var(--vz-tx) !important; }
.vz-topbar + div:has(> div > a) > div > a::after {
    content: ''; position: absolute; left: 14px; right: 14px; bottom: -1px; height: 2px; border-radius: 2px; background: var(--vz-accent);
    transform: scaleX(0); transition: transform var(--vz-base) var(--vz-ease);
}
.vz-topbar + div:has(> div > a) > div > a.active { color: #fff !important; }
.vz-topbar + div:has(> div > a) > div > a.active::after { transform: scaleX(1); }

/* ---------------------------------------------------------------- page */
[class*='ContentContainer-sc'], [class^='ContentContainer'] { box-sizing: border-box; max-width: 1240px !important; padding-left: clamp(16px, 2.4vw, 32px); padding-right: clamp(16px, 2.4vw, 32px); margin-left: auto !important; margin-right: auto !important; }
.vz-page-head { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; margin-bottom: 20px; }
.vz-page-head h1 { font-size: 26px; font-weight: 600; line-height: 1.15; }
.vz-page-head p { margin-top: 4px; font-size: 13px; color: var(--vz-tx3); }
.fade-enter { opacity: 0; transform: translateY(8px); }
.fade-enter-active { opacity: 1; transform: none; transition: opacity 220ms ease, transform 260ms var(--vz-ease); }
.fade-exit { opacity: 1; }
.fade-exit-active { opacity: 0; transition: opacity 120ms ease; }

/* ---------------------------------------------------------------- surfaces */
[class*='GreyRowBox'], [class*='ServerRow__StatusIndicatorBox'] {
    background: var(--vz-surface) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-lg) !important;
    box-shadow: var(--vz-sh1); transition: transform var(--vz-base) var(--vz-ease), border-color var(--vz-fast) ease, background-color var(--vz-fast) ease, box-shadow var(--vz-base) ease !important;
}
a[class*='ServerRow__StatusIndicatorBox'] { padding: 16px 20px !important; }
a[class*='ServerRow__StatusIndicatorBox']:hover, [class*='GreyRowBox']:hover {
    background: var(--vz-elev) !important; border-color: var(--vz-bd-strong); transform: translateY(-1px) scale(1.002); box-shadow: var(--vz-sh2);
}
[class^='ServerRow__Icon-sc'], [class*=' ServerRow__Icon-sc'], .icon { background: rgba(255, 255, 255, 0.04) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-md) !important; }
[class*='ServerRow__StatusIndicatorBox'] .status-bar {
    width: 8px !important; height: 8px !important; top: 50%; right: 18px !important; margin: 0 !important; transform: translateY(-50%);
    border-radius: 50% !important; opacity: 1 !important; box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.05);
}
[class*='TitledGreyBox___StyledDiv']:not([class*='StyledDiv2']):not([class*='StyledDiv3']) {
    background: var(--vz-surface) !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-lg) !important; box-shadow: var(--vz-sh1); overflow: hidden;
}
[class*='TitledGreyBox___StyledDiv2'] { background: var(--vz-elev) !important; border-bottom: 1px solid var(--vz-bd); padding: 12px 16px !important; font-size: 13px; font-weight: 500; }
.vz-skeleton-list { display: flex; flex-direction: column; gap: 8px; }
.vz-skel { height: 76px; border-radius: var(--vz-r-lg); border: 1px solid var(--vz-bd);
    background: linear-gradient(100deg, var(--vz-surface) 30%, var(--vz-elev) 50%, var(--vz-surface) 70%); background-size: 250% 100%; animation: vzShimmer 2.2s ease-in-out infinite; }

/* ---------------------------------------------------------------- controls */
[class*='Button__ButtonStyle'] {
    border-radius: var(--vz-r-md) !important; font-weight: 500 !important; letter-spacing: 0 !important; border-width: 1px !important;
    transition: transform var(--vz-fast) ease, filter var(--vz-fast) ease, box-shadow var(--vz-base) ease, background-color var(--vz-fast) ease, border-color var(--vz-fast) ease !important;
}
[class*='Button__ButtonStyle']:hover:not(:disabled) { filter: brightness(1.1); box-shadow: 0 6px 18px -8px rgba(79, 140, 255, 0.55); }
[class*='Button__ButtonStyle']:active:not(:disabled), button:active:not(:disabled) { transform: scale(0.97); }
[class*='Button__ButtonStyle']:disabled { opacity: 0.5; cursor: not-allowed; }
input:not([type='checkbox']):not([type='radio']):not([type='file']):not([type='range']), textarea, select {
    background-color: rgba(255, 255, 255, 0.035) !important; border: 1px solid var(--vz-bd-strong) !important; border-radius: var(--vz-r-md) !important;
    color: var(--vz-tx) !important; transition: border-color var(--vz-fast) ease, box-shadow var(--vz-base) ease, background-color var(--vz-fast) ease !important;
}
input:not([type='checkbox']):not([type='radio']):not([type='file']):hover, textarea:hover, select:hover { border-color: rgba(255, 255, 255, 0.2) !important; }
input:not([type='checkbox']):not([type='radio']):not([type='file']):focus, textarea:focus, select:focus {
    border-color: var(--vz-accent) !important; background-color: rgba(79, 140, 255, 0.05) !important; box-shadow: 0 0 0 3px rgba(79, 140, 255, 0.18) !important;
}
input::placeholder, textarea::placeholder { color: var(--vz-tx3) !important; }
input:disabled, textarea:disabled, select:disabled { opacity: 0.55; cursor: not-allowed; }
input[type='checkbox'], input[type='radio'] { accent-color: var(--vz-accent); }
label, [class*='Label'] { color: var(--vz-tx2); font-weight: 500; }
[class*='InputError'] { color: var(--vz-err) !important; }
[class*='Switch__ToggleContainer'], [class*='Switch___StyledToggleContainer'] { transition: background-color var(--vz-base) ease !important; }
[class*='Switch__ToggleContainer'] > *, [class*='Switch___StyledToggleContainer'] > * { transition: transform var(--vz-base) var(--vz-ease), background-color var(--vz-base) ease !important; }
[class*='ProgressBar'] { border-radius: 99px !important; height: 4px !important; }
[class*='ProgressBar__BarFill'] { border-radius: 99px !important; transition: width var(--vz-slow) var(--vz-ease) !important; }
[class*='Spinner__SpinnerComponent'] { filter: none; }
[class*='SpinnerOverlay___StyledDiv'] { -webkit-backdrop-filter: blur(4px); backdrop-filter: blur(4px); }

/* ---------------------------------------------------------------- overlays */
[class*='Modal__ModalMask'] { background: rgba(4, 6, 10, 0.66) !important; -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); }
[class*='Modal__ModalContainer'] {
    background: var(--vz-elev) !important; border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-xl) !important; box-shadow: var(--vz-sh3) !important;
    animation: vzModal 200ms var(--vz-ease) backwards;
}
@media (max-width: 640px) { [class*='Modal__ModalContainer'] { width: calc(100vw - 24px) !important; max-height: calc(100vh - 24px); overflow-y: auto; } }
[class*='DropdownMenu___StyledDiv'] {
    background: var(--vz-elev2) !important; border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-lg) !important; box-shadow: var(--vz-sh2) !important;
    animation: vzPop 140ms var(--vz-ease) backwards; transform-origin: top right;
}
[class*='DropdownMenu__DropdownButtonRow'], [class*='FileDropdownMenu__StyledRow'] { border-radius: var(--vz-r-sm) !important; transition: background-color var(--vz-fast) ease !important; }
[role='tooltip'] { border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-sm) !important; background: var(--vz-elev2) !important; box-shadow: var(--vz-sh2); font-size: 12px; }
[class*='MessageBox__Container'] {
    border-radius: var(--vz-r-md) !important; border: 1px solid var(--vz-bd-strong) !important; background: var(--vz-elev) !important; box-shadow: var(--vz-sh2);
    animation: vzSlide 260ms var(--vz-ease) backwards;
}

/* ---------------------------------------------------------------- console / files / editor / charts */
.xterm { padding: 12px 14px; font-family: var(--vz-mono) !important; }
.xterm-viewport::-webkit-scrollbar { width: 8px; }
div:has(> .xterm) { background: #05070A !important; border: 1px solid var(--vz-bd); border-radius: var(--vz-r-lg); overflow: hidden; }
[class*='FileObjectRow___StyledDiv'] { border-radius: var(--vz-r-sm); transition: background-color var(--vz-fast) ease !important; }
[class*='FileObjectRow___StyledDiv']:hover { background: rgba(255, 255, 255, 0.045) !important; }
[class*='FileManagerBreadcrumbs'] { font-size: 13px; }
.cm-editor, [class*='CodemirrorEditor__EditorContainer'] { background: #05070A !important; border-radius: var(--vz-r-lg); font-family: var(--vz-mono) !important; }
.cm-gutters { background: #05070A !important; border-right: 1px solid var(--vz-bd) !important; color: var(--vz-tx3) !important; }
.cm-activeLine, .cm-activeLineGutter { background: rgba(255, 255, 255, 0.035) !important; }
.cm-selectionBackground, .cm-editor .cm-selectionBackground { background: rgba(79, 140, 255, 0.28) !important; }
canvas { border-radius: var(--vz-r-sm); }
table { border-collapse: collapse; }
th { color: var(--vz-tx3); font-weight: 500; font-size: 11px; text-transform: uppercase; letter-spacing: 0.06em; }
tbody tr { border-top: 1px solid var(--vz-bd); transition: background-color var(--vz-fast) ease; } tbody tr:hover { background: rgba(255, 255, 255, 0.03); }

/* ---------------------------------------------------------------- auth */
body:has(form img[src*='pterodactyl.svg'])::before {
    background:
        radial-gradient(760px 480px at 50% -6%, rgba(79, 140, 255, 0.16), transparent 70%),
        radial-gradient(600px 420px at 85% 90%, rgba(120, 140, 200, 0.06), transparent 70%),
        linear-gradient(180deg, var(--vz-bg2), var(--vz-bg));
}
form > div:has(> div > img[src*='pterodactyl.svg']) {
    display: block !important; max-width: 420px; margin: 0 auto !important; padding: 32px !important;
    background: rgba(16, 21, 29, 0.78) !important; border: 1px solid var(--vz-bd-strong); border-radius: var(--vz-r-xl) !important;
    box-shadow: var(--vz-sh3), inset 0 1px 0 rgba(255, 255, 255, 0.05) !important; -webkit-backdrop-filter: blur(18px); backdrop-filter: blur(18px);
    animation: vzModal 420ms var(--vz-ease) backwards;
}
form > div:has(> div > img[src*='pterodactyl.svg']) > div:first-child { margin: 0 0 24px !important; display: flex; justify-content: center; }
form img[src*='pterodactyl.svg'] { width: 56px !important; height: 56px; margin: 0 !important; filter: brightness(0) invert(1) drop-shadow(0 0 16px rgba(79, 140, 255, 0.35)); }
form > div:has(> div > img[src*='pterodactyl.svg']) label { color: var(--vz-tx2) !important; }
form > div:has(> div > img[src*='pterodactyl.svg']) a { color: var(--vz-tx3) !important; text-decoration: none; }
form > div:has(> div > img[src*='pterodactyl.svg']) a:hover { color: var(--vz-accent-h) !important; }
form > div:has(> div > img[src*='pterodactyl.svg']) > div:last-child > * { animation: vzRise 480ms var(--vz-ease) backwards; }
form > div:has(> div > img[src*='pterodactyl.svg']) > div:last-child > *:nth-child(2) { animation-delay: 60ms; }
form > div:has(> div > img[src*='pterodactyl.svg']) > div:last-child > *:nth-child(3) { animation-delay: 120ms; }
form > div:has(> div > img[src*='pterodactyl.svg']) > div:last-child > *:nth-child(4) { animation-delay: 180ms; }

/* ---------------------------------------------------------------- motion */
@keyframes vzRise { from { opacity: 0; transform: translateY(10px); } }
@keyframes vzModal { from { opacity: 0; transform: translateY(8px) scale(0.97); } }
@keyframes vzPop { from { opacity: 0; transform: scale(0.96); } }
@keyframes vzSlide { from { opacity: 0; transform: translateY(-8px); } }
@keyframes vzShimmer { from { background-position: 150% 0; } to { background-position: -50% 0; } }

/* ---------------------------------------------------------------- responsive */
@media (max-width: 1023px) {
    .vz-only-mobile { display: inline-flex !important; }
    .vz-only-desktop { display: none !important; }
    .vz-side { width: 272px; transform: translateX(-102%); box-shadow: none; z-index: 60; }
    .vz-side[data-open='1'] { transform: none; box-shadow: var(--vz-sh3); }
    .vz-scrim { display: block; position: fixed; inset: 0; z-index: 55; background: rgba(4, 6, 10, 0.6); -webkit-backdrop-filter: blur(3px); backdrop-filter: blur(3px); opacity: 0; pointer-events: none; transition: opacity var(--vz-base) ease; }
    .vz-scrim[data-open='1'] { opacity: 1; pointer-events: auto; }
    .vz-topbar { padding: 0 14px; }
    .vz-search { min-width: 0; width: 34px; padding: 0; justify-content: center; }
    .vz-search span, .vz-search kbd { display: none; }
}
@media (max-width: 640px) {
    .vz-page-head { flex-direction: column; align-items: flex-start; }
    .vz-page-head h1 { font-size: 22px; }
    a[class*='ServerRow__StatusIndicatorBox'] { padding: 14px 40px 14px 14px !important; }
}
@media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; transition-duration: 0.01ms !important; scroll-behavior: auto !important; }
}
`;
