/* Vizion Mono v4 - interaction + colour layer. Loaded after the panel; safe to load twice. */
(function () {
  if (window.__vizionMono) return; window.__vizionMono = true;
  var D = document, H = D.documentElement, reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  try { var m = D.querySelector('meta[name=theme-color]'); if (m) m.content = '#08080a'; } catch (e) {}

  /* ---- colour classification -------------------------------------------------------- */
  function parse(c) {
    var m = c && c.match(/rgba?\(([^)]+)\)/); if (!m) return null;
    var p = m[1].split(/[ ,\/]+/).filter(Boolean).map(parseFloat);
    return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 };
  }
  function hsl(o) {
    var r = o.r / 255, g = o.g / 255, b = o.b / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn, h = 0, s = 0;
    if (d) {
      s = d / (1 - Math.abs(2 * l - 1));
      h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
      h = (h * 60 + 360) % 360;
    }
    return { h: h, s: s, l: l };
  }
  // strongly saturated cyan/blue/indigo
  function isBlue(c) { var o = parse(c); if (!o || o.a < .08) return false; var x = hsl(o); return x.h >= 170 && x.h <= 265 && x.s >= .45 && x.l > .06 && x.l < .97; }
  // the panel's blue-grey surface palette -> returns bucket 1..6 or 0
  function greyBucket(c) {
    var o = parse(c); if (!o || o.a < .5) return 0; var x = hsl(o);
    if (!(x.h >= 190 && x.h <= 240 && x.s >= .08 && x.s < .45 && x.l < .5)) return 0;
    return x.l < .12 ? 1 : x.l < .2 ? 2 : x.l < .27 ? 3 : x.l < .34 ? 4 : x.l < .42 ? 5 : 6;
  }
  var ATTRS = ['data-vz-bg', 'data-vz-fg', 'data-vz-bd', 'data-vz-fill', 'data-vz-stroke', 'data-vz-g', 'data-vz-gb'];
  function tag(el) {
    if (el.nodeType !== 1 || el.id === 'vz-glow' || el.id === 'vz-bar') return;
    ATTRS.forEach(function (a) { if (el.hasAttribute(a)) el.removeAttribute(a); });
    if (el.dataset.vzSh) { el.style.removeProperty('box-shadow'); delete el.dataset.vzSh; }
    var cs = getComputedStyle(el);
    if (cs.display === 'none') return;
    var bg = cs.backgroundColor;
    if (isBlue(bg)) el.setAttribute('data-vz-bg', '');
    else { var g = greyBucket(bg); if (g) el.setAttribute('data-vz-g', g); }
    if (isBlue(cs.color)) el.setAttribute('data-vz-fg', '');
    if (cs.borderStyle !== 'none' && (isBlue(cs.borderTopColor) || isBlue(cs.borderBottomColor) || isBlue(cs.borderLeftColor) || isBlue(cs.borderRightColor))) el.setAttribute('data-vz-bd', '');
    else if (cs.borderStyle !== 'none' && (greyBucket(cs.borderBottomColor) || greyBucket(cs.borderTopColor))) el.setAttribute('data-vz-gb', '');
    if (el instanceof SVGElement) {
      if (isBlue(cs.fill)) el.setAttribute('data-vz-fill', ''); if (isBlue(cs.stroke)) el.setAttribute('data-vz-stroke', '');
    }
    var sh = cs.boxShadow;
    if (sh && sh !== 'none' && /rgba?\(/.test(sh)) {
      var changed = false, out = sh.replace(/rgba?\([^)]+\)/g, function (c) { if (isBlue(c)) { changed = true; return 'rgba(235,235,240,' + (parse(c).a) + ')'; } return c; });
      if (changed) { el.style.setProperty('box-shadow', out, 'important'); el.dataset.vzSh = '1'; }
    }
  }
  var queue = [], scheduled = false;
  function pump() {
    var t0 = performance.now();
    while (queue.length && performance.now() - t0 < 6) tag(queue.pop());
    if (queue.length) setTimeout(pump, 16); else scheduled = false;
  }
  function enqueue(node) {
    if (node.nodeType !== 1) return;
    queue.push(node); var all = node.querySelectorAll('*'); for (var i = 0; i < all.length; i++) queue.push(all[i]);
    if (!scheduled) { scheduled = true; setTimeout(pump, 0); }
  }
  new MutationObserver(function (list) {
    for (var i = 0; i < list.length; i++) {
      var r = list[i];
      if (r.type === 'attributes') { if (r.target.nodeType === 1 && !r.target.dataset.vzSh) queue.push(r.target); }
      else for (var j = 0; j < r.addedNodes.length; j++) enqueue(r.addedNodes[j]);
    }
    if (queue.length && !scheduled) { scheduled = true; setTimeout(pump, 0); }
  }).observe(D.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  D.addEventListener('focusin', function (e) { if (e.target && e.target.nodeType === 1) { queue.push(e.target); if (!scheduled) { scheduled = true; setTimeout(pump, 0); } } }, true);
  D.addEventListener('focusout', function (e) { if (e.target && e.target.nodeType === 1) setTimeout(function () { tag(e.target); }, 0); }, true);
  enqueue(D.body || H);
  D.addEventListener('DOMContentLoaded', function () { enqueue(D.body); });

  /* ---- cursor glow, card spotlight, tilt -------------------------------------------- */
  var glow = D.createElement('div'); glow.id = 'vz-glow'; var bar = D.createElement('div'); bar.id = 'vz-bar';
  function mount() { if (D.body && !glow.parentNode) { D.body.appendChild(glow); D.body.appendChild(bar); } }
  mount(); D.addEventListener('DOMContentLoaded', mount);
  var CARD = '[class*="GreyRowBox"],[class*="TitledGreyBox___StyledDiv-sc"],[class*="DashboardContainer___StyledServerRow"],[class*="FileObjectRow"]';
  var TILT = '[class*="DashboardContainer___StyledServerRow"]', raf = 0, px = 0, py = 0, pt = null, lastTilt = null;
  D.addEventListener('pointermove', function (e) {
    px = e.clientX; py = e.clientY; pt = e.target;
    if (raf) return;
    raf = requestAnimationFrame(function () {
      raf = 0; if (reduce) return;
      glow.style.transform = 'translate3d(' + px + 'px,' + py + 'px,0)';
      var c = pt && pt.closest && pt.closest(CARD);
      if (c) {
        var r = c.getBoundingClientRect(); c.style.setProperty('--mx', (px - r.left) + 'px'); c.style.setProperty('--my', (py - r.top) + 'px');
        if (c.matches(TILT) && !matchMedia('(pointer:coarse)').matches) {
          c.style.setProperty('--ry', (((px - r.left) / r.width - .5) * 5).toFixed(2) + 'deg'); c.style.setProperty('--rx', ((.5 - (py - r.top) / r.height) * 4).toFixed(2) + 'deg'); lastTilt = c;
        }
      }
      if (lastTilt && lastTilt !== c) { lastTilt.style.removeProperty('--rx'); lastTilt.style.removeProperty('--ry'); lastTilt = null; }
    });
  }, { passive: true });
  D.addEventListener('pointerleave', function () { glow.style.opacity = 0; }); D.addEventListener('pointerenter', function () { glow.style.opacity = 1; });

  /* ---- route progress bar ----------------------------------------------------------- */
  function run() { bar.classList.remove('run'); void bar.offsetWidth; bar.classList.add('run'); }
  ['pushState', 'replaceState'].forEach(function (k) { var o = history[k]; history[k] = function () { var r = o.apply(this, arguments); run(); return r; }; });
  addEventListener('popstate', run);
})();
