<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Middleware\Activity\ServerSubject;
use Pterodactyl\Http\Middleware\Api\Client\Server\ResourceBelongsToServer;
use Pterodactyl\Http\Middleware\Api\Client\Server\AuthenticateServerAccess;

/*
|--------------------------------------------------------------------------
| Vizion theme routes
|--------------------------------------------------------------------------
|
| Loaded from the bottom of routes/api-client.php, so they inherit the /api/client
| prefix and the client API middleware.
*/
// Older Vizion releases declared the Player Manager routes inside api-client.php themselves.
if (!str_contains((string) @file_get_contents(__DIR__ . '/api-client.php'), "'/playermanager'")) {
    Route::group([
        'prefix' => '/servers/{server}/playermanager',
        'middleware' => [
            ServerSubject::class,
            AuthenticateServerAccess::class,
            ResourceBelongsToServer::class,
            \Pterodactyl\Http\Middleware\Api\Client\Server\IsMinecraft::class,
        ],
    ], function () {
        Route::get('/', [\Pterodactyl\Http\Controllers\Api\Client\Servers\MinecraftPlayerManagerController::class, 'index']);
        Route::post('/command', [\Pterodactyl\Http\Controllers\Api\Client\Servers\MinecraftPlayerManagerController::class, 'runCommand']);
    });
}
