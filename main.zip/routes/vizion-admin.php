<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Admin\VizionController;

/*
|--------------------------------------------------------------------------
| Vizion theme: Admin → Appearance
|--------------------------------------------------------------------------
|
| Loaded from the bottom of routes/admin.php, so these inherit the /admin prefix and the
| administrator-only middleware of that file.
*/
Route::prefix('/vizion')->group(function () {
    Route::get('/', [VizionController::class, 'index'])->name('admin.vizion');
    Route::post('/', [VizionController::class, 'save']);
    Route::post('/background', [VizionController::class, 'background']);
    Route::delete('/', [VizionController::class, 'reset']);
});
