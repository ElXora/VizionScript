const colors = require('tailwindcss/colors');

const gray = {
    50: 'var(--vz-g50)',
    100: 'var(--vz-g100)',
    200: 'var(--vz-g200)',
    300: 'var(--vz-g300)',
    400: 'var(--vz-g400)',
    500: 'var(--vz-g500)',
    600: 'var(--vz-g600)',
    700: 'var(--vz-g700)',
    800: 'var(--vz-g800)',
    900: 'var(--vz-g900)',
};

// Vizion accent. Both ramps are CSS variables so Light / Dark / OLED mode and the accent colour
// can be switched at runtime from the Appearance editor (see plugins/appearance.ts).
const accent = {
    50: 'var(--vz-p50)',
    100: 'var(--vz-p100)',
    200: 'var(--vz-p200)',
    300: 'var(--vz-p300)',
    400: 'var(--vz-p400)',
    500: 'var(--vz-p500)',
    600: 'var(--vz-p600)',
    700: 'var(--vz-p700)',
    800: 'var(--vz-p800)',
    900: 'var(--vz-p900)',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
                mono: ['"JetBrains Mono"', '"SF Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace'],
            },
            colors: {
                black: '#05070A',
                // "primary" and "neutral" are deprecated, prefer the use of "blue" and "gray"
                // in new code.
                primary: accent,
                gray: gray,
                neutral: gray,
                cyan: accent,
                blue: accent,
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};
