const colors = require('tailwindcss/colors');

const gray = {
    50: '#F5F7FA',
    100: '#E6E9EF',
    200: '#C9CFD9',
    300: '#A8B0BD',
    400: '#7D8797',
    500: '#596273',
    600: '#1A2230',
    700: '#10151D',
    800: '#0A0E14',
    900: '#07090D',
};

// Vizion accent (used for primary actions, focus and active states only)
const accent = {
    50: '#EEF4FF',
    100: '#DCE8FF',
    200: '#BCD3FF',
    300: '#93B7FF',
    400: '#6A9CFF',
    500: '#4F8CFF',
    600: '#3A74E8',
    700: '#2D5BC0',
    800: '#264A99',
    900: '#223F78',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
                mono: ['"JetBrains Mono"', '"SF Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace'],
            },
            colors: {
                black: '#05070A',
                // "primary" and "neutral" are deprecated, prefer the use of "blue" and "gray"
                // in new code.
                primary: accent,
                gray: gray,
                neutral: gray,
                cyan: accent,
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};
